// FASHION FIND — générateur de l'identité visuelle (monogramme FF).
// Source unique de vérité : toute la géométrie du logo est définie ici.
// Usage :  node tools/build-brand.mjs
// Produit : assets/brand/*.svg, *.png, favicon.ico, assets/js/ff-logo.js

import { writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = join(ROOT, 'assets', 'brand');
mkdirSync(OUT, { recursive: true });
mkdirSync(join(ROOT, 'assets', 'js'), { recursive: true });

export const BLUE = '#075BFF';
export const BLACK = '#000000';
export const WHITE = '#FFFFFF';

const r = (n) => +n.toFixed(2);

/* ------------------------------------------------------------------ *
 *  1. LE MONOGRAMME — grille 120 × 120, centre (60, 60)
 *
 *  D'après le logo de référence : un F à l'endroit en haut à gauche et
 *  son double retourné (rotation de 180° autour du centre) en bas à
 *  droite. Les deux lettres s'emboîtent sans se toucher : le bras médian
 *  de chaque F vient se loger dans le creux de l'autre. La composition
 *  est symétrique par rotation : retournée, elle reste identique.
 * ------------------------------------------------------------------ */
const G = {
  c: 60,        // centre de rotation
  x0: 32,       // bord gauche du fût du F
  top: 24,      // haut du F
  bot: 80,      // bas du fût du F
  stem: 14,     // épaisseur du fût
  bar: 13,      // épaisseur des bras
  topEnd: 69,   // extrémité du bras haut
  midTop: 45,   // haut du bras médian
  midEnd: 65,   // extrémité du bras médian
};

function upperF() {
  const { x0, top, bot, stem, bar, topEnd, midTop, midEnd } = G;
  const xs = x0 + stem;
  return [
    [x0, top], [topEnd, top], [topEnd, top + bar], [xs, top + bar],
    [xs, midTop], [midEnd, midTop], [midEnd, midTop + bar], [xs, midTop + bar],
    [xs, bot], [x0, bot],
  ];
}
const rotate180 = (pts) => pts.map(([x, y]) => [2 * G.c - x, 2 * G.c - y]);
const toD = (pts) => 'M' + pts.map(([x, y]) => `${r(x)},${r(y)}`).join(' L') + ' Z';

const F1 = upperF();
const F2 = rotate180(F1);
const D_L = toD(F1);
const D_R = toD(F2);

// Boîte serrée des lettres (pour les lockups)
const CROP = { x: G.x0, y: G.top, w: 2 * (G.c - G.x0), h: 2 * (G.c - G.top) };

/* Fragments (le jeton %ID% est remplacé par un identifiant unique) */
function monoSolidFrag(color) {
  return `<g class="ff-letters" fill="${color}"><path d="${D_L}"/><path d="${D_R}"/></g>`;
}

function emblemFrag({ bg = 'disc', ring = 3, outline = 2.2, scale = 1 } = {}) {
  const back =
    bg === 'disc' ? `<circle cx="60" cy="60" r="60" fill="${BLACK}"/>`
    : bg === 'square' ? `<rect width="120" height="120" fill="${BLACK}"/>`
    : '';
  const t = scale === 1 ? '' : ` transform="translate(60 60) scale(${scale}) translate(-60 -60)"`;
  return (
    back +
    `<circle class="ff-ring" cx="60" cy="60" r="53" fill="none" stroke="${BLUE}" stroke-width="${ring}" pathLength="1"/>` +
    `<g${t}>` +
    `<g class="ff-letters" fill="${WHITE}"><path d="${D_L}"/><path d="${D_R}"/></g>` +
    `<g class="ff-outline" fill="none" stroke="${BLUE}" stroke-width="${outline}" stroke-linejoin="miter">` +
    `<path d="${D_L}" pathLength="1"/><path d="${D_R}" pathLength="1"/></g>` +
    `</g>`
  );
}

/* ------------------------------------------------------------------ *
 *  2. LE LOGOTYPE — capitales géométriques dessinées au trait
 *     (hauteur de capitale 20, aucune dépendance à une police)
 * ------------------------------------------------------------------ */
const GLYPHS = {
  F: { w: 11, p: [['M11,0 H0 V20 M0,9.6 H9.4', 'square']] },
  A: { w: 16, l: -1.5, rt: -1.5, p: [['M0,20 L8,0 L16,20', 'square'], ['M2.8,13 H13.2', 'butt']] },
  S: { w: 13.2, l: -0.4, rt: -0.4, p: [['M12.6,3.6 C11.5,1.3 9.4,0 6.6,0 C3.3,0 0.9,1.9 0.9,5 C0.9,8.3 3.7,9.2 6.8,9.8 C10.3,10.5 13.2,11.6 13.2,15.1 C13.2,18.2 10.6,20 6.7,20 C3.6,20 1.1,18.7 0,16.3', 'butt']] },
  H: { w: 14, p: [['M0,0 V20 M14,0 V20 M0,10 H14', 'square']] },
  I: { w: 0, p: [['M0,0 V20', 'square']] },
  O: { w: 20, l: -0.4, rt: -0.4, p: [['M20,10 A10,10 0 1 1 0,10 A10,10 0 1 1 20,10 Z', 'butt']] },
  N: { w: 14, p: [['M0,20 V0 L14,20 V0', 'square']] },
  D: { w: 14.6, p: [['M0,0 H4.6 A10,10 0 0 1 4.6,20 H0 Z', 'butt']] },
  E: { w: 11, p: [['M11,0 H0 V20 H11 M0,9.6 H9.4', 'square']] },
  T: { w: 14, l: -1, rt: -1, p: [['M0,0 H14 M7,0 V20', 'square']] },
  W: { w: 22, l: -1.5, rt: -1.5, p: [['M0,0 L5.5,20 L11,0 L16.5,20 L22,0', 'square']] },
  R: { w: 13, p: [['M0,20 V0 H7.2 A5,5 0 0 1 7.2,10 H0', 'square'], ['M6.6,10 L13,20', 'square']] },
  '.': { w: 0, dot: true, p: [['M0,20 h0.01', 'square']] },
};

function textRun(text, { gap = 9, space = 22, sw = 1.9, color = '%C%', id = '%ID%', cls = '' } = {}) {
  let x = 0;
  let prev = null;
  const parts = [];
  for (const ch of text) {
    if (ch === ' ') { x += space; prev = null; continue; }
    const g = GLYPHS[ch];
    if (!g) throw new Error(`glyphe manquant : ${ch}`);
    if (prev) x += gap + (prev.rt || 0) + (g.l || 0) + (g.dot ? -gap * 0.55 : 0);
    for (const [d, cap] of g.p) {
      parts.push(`<path transform="translate(${r(x)} 0)" d="${d}" stroke-linecap="${cap}"/>`);
    }
    x += g.w;
    prev = g;
  }
  const h = sw / 2;
  const width = x;
  const svg =
    `<defs><clipPath id="${id}-c"><rect x="${-h - 2}" y="${-h}" width="${r(width + sw + 4)}" height="${r(20 + sw)}"/></clipPath></defs>` +
    `<g${cls ? ` class="${cls}"` : ''} clip-path="url(#${id}-c)" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linejoin="miter" stroke-miterlimit="6">${parts.join('')}</g>`;
  return { svg, width, h };
}

const WORD = { gap: 9, space: 22, sw: 1.9 };
const TAG = { gap: 12, space: 24, sw: 2.8 };

/* ------------------------------------------------------------------ *
 *  3. FICHIERS
 * ------------------------------------------------------------------ */
const svgDoc = (vb, body, title) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" role="img" aria-label="${title}"><title>${title}</title>${body}</svg>\n`;
const fill = (s, map) => Object.entries(map).reduce((acc, [k, v]) => acc.split(k).join(v), s);
const files = {};
const put = (name, content) => { files[name] = content; writeFileSync(join(OUT, name), content); };

// Monogramme seul — bleu / noir / blanc (fond transparent)
for (const [name, color] of [['blue', BLUE], ['black', BLACK], ['white', WHITE]]) {
  put(`ff-monogram-${name}.svg`, svgDoc(`${CROP.x - 2} ${CROP.y - 2} ${CROP.w + 4} ${CROP.h + 4}`, fill(monoSolidFrag(color), { '%ID%': `ffm-${name}` }), 'Fashion Find'));
}

// Emblème officiel : fond noir, cercle bleu, lettres blanches contour bleu
put('ff-emblem.svg', svgDoc('0 0 120 120', emblemFrag({ bg: 'disc' }), 'Fashion Find'));
put('ff-emblem-square.svg', svgDoc('0 0 120 120', emblemFrag({ bg: 'square' }), 'Fashion Find'));
// Favicon : traits renforcés pour rester lisible à 16–32 px
put('favicon.svg', svgDoc('0 0 120 120', emblemFrag({ bg: 'disc', ring: 6, outline: 3.6 }), 'Fashion Find'));

// Logotype et slogan
for (const [name, color] of [['blue', BLUE], ['black', BLACK], ['white', WHITE]]) {
  const w = textRun('FASHION FIND', { ...WORD, color, id: `ffw-${name}` });
  put(`ff-wordmark-${name}.svg`, svgDoc(`${-w.h} ${-w.h} ${r(w.width + 2 * w.h)} ${r(20 + 2 * w.h)}`, w.svg, 'FASHION FIND'));
  const t = textRun('SEE IT. FIND IT. WEAR IT.', { ...TAG, color, id: `fft-${name}` });
  put(`ff-tagline-${name}.svg`, svgDoc(`${-t.h} ${-t.h} ${r(t.width + 2 * t.h)} ${r(20 + 2 * t.h)}`, t.svg, 'SEE IT. FIND IT. WEAR IT.'));
}

// Lockup horizontal : monogramme + FASHION FIND
function lockupH(color, id) {
  const H = 46;
  const s = H / CROP.h;
  const mw = CROP.w * s;
  const w = textRun('FASHION FIND', { ...WORD, color, id: `${id}-w` });
  const wx = mw + 20 + w.h;
  const wy = H / 2 - 10;
  const body =
    `<g transform="scale(${r(s * 1000) / 1000}) translate(${-CROP.x} ${-CROP.y})">${monoSolidFrag(color, `${id}-m`)}</g>` +
    `<g transform="translate(${r(wx)} ${r(wy)})">${w.svg}</g>`;
  return svgDoc(`0 0 ${r(wx + w.width + w.h)} ${H}`, body, 'Fashion Find');
}
for (const [name, color] of [['blue', BLUE], ['black', BLACK], ['white', WHITE]]) {
  put(`ff-lockup-${name}.svg`, lockupH(color, `ffl-${name}`));
}

// Lockup vertical officiel : emblème + FASHION FIND + slogan, fond noir
function lockupV() {
  const W = 360, E = 150, pad = 44;
  const w = textRun('FASHION FIND', { ...WORD, color: WHITE, id: 'ffv-w' });
  const t = textRun('SEE IT. FIND IT. WEAR IT.', { ...TAG, color: BLUE, id: 'ffv-t' });
  const ts = 0.42;
  const ey = pad, wy = ey + E + 34, ty = wy + 20 + 22;
  const H = ty + 20 * ts + pad;
  const body =
    `<rect width="${W}" height="${r(H)}" fill="${BLACK}"/>` +
    `<g transform="translate(${(W - E) / 2} ${ey}) scale(${E / 120})">${emblemFrag({ bg: 'none' })}</g>` +
    `<g transform="translate(${r((W - w.width) / 2)} ${wy})">${w.svg}</g>` +
    `<g transform="translate(${r((W - t.width * ts) / 2)} ${ty}) scale(${ts})">${t.svg}</g>`;
  return svgDoc(`0 0 ${W} ${r(H)}`, body, 'FASHION FIND — SEE IT. FIND IT. WEAR IT.');
}
put('ff-lockup-emblem.svg', lockupV());

// Badge de notification (Android) : monogramme blanc sur transparent
put('ff-badge.svg', svgDoc('0 0 120 120', `<g transform="translate(60 60) scale(1.3) translate(-60 -60)">${fill(monoSolidFrag(WHITE), { '%ID%': 'ffb' })}</g>`, 'Fashion Find'));

/* ------------------------------------------------------------------ *
 *  4. SCRIPT NAVIGATEUR (logo inline, animable, toutes pages)
 * ------------------------------------------------------------------ */
const wordRun = textRun('FASHION FIND', { ...WORD });
const tagRun = textRun('SEE IT. FIND IT. WEAR IT.', { ...TAG });
const js = `/* FASHION FIND — logo inline. Fichier généré par tools/build-brand.mjs : ne pas modifier à la main. */
(function () {
  var T = ${JSON.stringify({
    emblem: emblemFrag({ bg: 'disc' }),
    emblemBare: emblemFrag({ bg: 'none' }),
    mono: monoSolidFrag('%C%'),
    word: wordRun.svg,
    tag: tagRun.svg,
  })};
  var M = ${JSON.stringify({ crop: CROP, word: { w: wordRun.width, h: wordRun.h }, tag: { w: tagRun.width, h: tagRun.h }, left: D_L, right: D_R, blue: BLUE })};
  var n = 0;
  function uid() { n += 1; return 'ff' + n + Math.random().toString(36).slice(2, 6); }
  function sub(s, c) { return s.split('%ID%').join(uid()).split('%C%').join(c || 'currentColor'); }
  function wrap(vb, body, label, cls) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '" class="' + (cls || '') + '" role="img" aria-label="' + label + '" focusable="false">' + body + '</svg>';
  }
  var api = {
    meta: M,
    emblem: function (cls) { return wrap('0 0 120 120', sub(T.emblem), 'Fashion Find', cls); },
    emblemBare: function (cls) { return wrap('0 0 120 120', sub(T.emblemBare), 'Fashion Find', cls); },
    mono: function (color, cls) {
      var c = M.crop;
      return wrap((c.x - 2) + ' ' + (c.y - 2) + ' ' + (c.w + 4) + ' ' + (c.h + 4), sub(T.mono, color), 'Fashion Find', cls);
    },
    wordmark: function (color, cls) {
      var h = M.word.h;
      return wrap((-h) + ' ' + (-h) + ' ' + (M.word.w + 2 * h) + ' ' + (20 + 2 * h), sub(T.word, color), 'FASHION FIND', cls);
    },
    tagline: function (color, cls) {
      var h = M.tag.h;
      return wrap((-h) + ' ' + (-h) + ' ' + (M.tag.w + 2 * h) + ' ' + (20 + 2 * h), sub(T.tag, color), 'SEE IT. FIND IT. WEAR IT.', cls);
    },
    /* <span data-ff-logo="emblem|emblem-bare|mono|wordmark|tagline" data-color="#075BFF"></span> */
    mount: function (root) {
      (root || document).querySelectorAll('[data-ff-logo]').forEach(function (el) {
        var kind = el.getAttribute('data-ff-logo');
        var color = el.getAttribute('data-color');
        var html = kind === 'emblem' ? api.emblem()
          : kind === 'emblem-bare' ? api.emblemBare()
          : kind === 'mono' ? api.mono(color)
          : kind === 'wordmark' ? api.wordmark(color)
          : kind === 'tagline' ? api.tagline(color) : '';
        el.innerHTML = html;
        el.removeAttribute('data-ff-logo');
        el.classList.add('ff-logo', 'ff-logo--' + kind);
      });
    },
  };
  window.FFLogo = api;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { api.mount(); });
  else api.mount();
})();
`;
writeFileSync(join(ROOT, 'assets', 'js', 'ff-logo.js'), js);

/* ------------------------------------------------------------------ *
 *  5. PNG + ICO (rendu via Microsoft Edge headless)
 * ------------------------------------------------------------------ */
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const rasters = [
  ['favicon-16.png', 'favicon.svg', 16],
  ['favicon-32.png', 'favicon.svg', 32],
  ['favicon-48.png', 'favicon.svg', 48],
  ['apple-touch-icon.png', 'ff-emblem-square.svg', 180],
  ['icon-192.png', 'ff-emblem-square.svg', 192],
  ['icon-512.png', 'ff-emblem-square.svg', 512],
  ['icon-maskable-512.png', 'ff-emblem-square.svg', 512, 0.78],
  ['badge-96.png', 'ff-badge.svg', 96],
  ['ff-emblem-1024.png', 'ff-emblem.svg', 1024],
  ['ff-lockup-emblem.png', 'ff-lockup-emblem.svg', 1080],
];
try {
  const jobs = rasters.map(([out, src, size, inset]) => ({
    out, size, inset: inset || 1,
    uri: 'data:image/svg+xml;base64,' + Buffer.from(files[src]).toString('base64'),
  }));
  const page = `<!doctype html><meta charset="utf-8"><body><pre id="o"></pre><script>
const jobs=${JSON.stringify(jobs)};const res={};
Promise.all(jobs.map(j=>new Promise(ok=>{const i=new Image();i.onload=()=>{
  const ar=i.naturalHeight/i.naturalWidth||1;const W=j.size,H=Math.round(j.size*ar);
  const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d');
  if(j.inset<1){x.fillStyle='#000';x.fillRect(0,0,W,H);}
  const w=W*j.inset,h=H*j.inset;x.drawImage(i,(W-w)/2,(H-h)/2,w,h);
  res[j.out]=c.toDataURL('image/png').split(',')[1];ok();};i.onerror=()=>ok();i.src=j.uri;})))
.then(()=>{document.getElementById('o').textContent='@@'+JSON.stringify(res)+'@@';});
</script>`;
  const tmp = join(tmpdir(), `ff-brand-${process.pid}.html`);
  writeFileSync(tmp, page);
  const dom = execFileSync(EDGE, ['--headless=new', '--disable-gpu', '--virtual-time-budget=8000', '--dump-dom', 'file:///' + tmp.replace(/\\/g, '/')], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  rmSync(tmp, { force: true });
  const m = dom.match(/<pre id="o">@@(.*?)@@<\/pre>/s);
  if (!m) throw new Error('rendu Edge vide');
  const pngs = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
  for (const [name, b64] of Object.entries(pngs)) writeFileSync(join(OUT, name), Buffer.from(b64, 'base64'));

  // favicon.ico (PNG 16/32/48 embarqués)
  const sizes = [16, 32, 48];
  const imgs = sizes.map((s) => Buffer.from(pngs[`favicon-${s}.png`], 'base64'));
  const head = Buffer.alloc(6 + 16 * imgs.length);
  head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(imgs.length, 4);
  let off = head.length;
  imgs.forEach((b, i) => {
    const e = 6 + 16 * i;
    head.writeUInt8(sizes[i], e); head.writeUInt8(sizes[i], e + 1);
    head.writeUInt16LE(1, e + 4); head.writeUInt16LE(32, e + 6);
    head.writeUInt32LE(b.length, e + 8); head.writeUInt32LE(off, e + 12);
    off += b.length;
  });
  writeFileSync(join(ROOT, 'favicon.ico'), Buffer.concat([head, ...imgs]));
  console.log(`PNG : ${Object.keys(pngs).length} fichiers + favicon.ico`);
} catch (e) {
  console.warn('PNG non générés (Edge introuvable ?) :', e.message);
}
console.log(`SVG : ${Object.keys(files).length} fichiers dans assets/brand`);
