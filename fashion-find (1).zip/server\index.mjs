// FASHION FIND — serveur : site + API marketplace (comptes, annonces, photos, recherche,
// profils, favoris, avis, recherche par image, WANTED, notifications).
// Usage : npm start   (port 8090, ou PORT=xxxx)
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { extname, join, normalize, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, randomBytes } from 'node:crypto';
import { openDb, searchText, normText, CATEGORY_NAME } from './db.mjs';
import { CATEGORIES, CONDITIONS, COLORS, SIZES, slugify } from './reference.mjs';
import { hashPassword, verifyPassword, createSession, destroySession, readCookie, sessionCookie, currentUser, rateLimit } from './auth.mjs';
import { rank } from './search.mjs';
import { analyzeImage, VisionUnavailable, MODEL } from './vision.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const DATA = join(ROOT, 'data');
const UPLOADS = join(DATA, 'uploads');
const PORT = Number(process.env.PORT || process.argv[2]) || 8090;
const SECURE = process.env.FF_SECURE_COOKIE === '1';
await mkdir(UPLOADS, { recursive: true });
const db = openDb(DATA);

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json',
};
const COND_NAME = Object.fromEntries(CONDITIONS.map((c) => [c.slug, c.name]));
const now = () => new Date().toISOString();

/* ---------- HTTP ---------- */
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => { throw new HttpError(status, message); };

function send(res, status, body, headers = {}) {
  if (status === 204) { res.writeHead(204, headers); res.end(); return; }
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(body));
}
function readBody(req, max = 1024 * 1024) {
  return new Promise((ok, ko) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > max) { ko(new HttpError(413, 'Request too large.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { ok(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { ko(new HttpError(400, 'Invalid JSON.')); }
    });
    req.on('error', ko);
  });
}
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const bool = (v) => (v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0);
function ip(req) { return (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }

/* ---------- Mise en forme ---------- */
const photoUrl = (p, thumb) => `/uploads/${p.id}${thumb ? '_t' : ''}.${p.ext}`;
const avatarUrl = (id) => {
  if (!id) return null;
  const p = db.prepare('SELECT id, ext FROM photos WHERE id = ?').get(id);
  return p ? photoUrl(p, true) : null;
};

function card(l) {
  const photo = db.prepare('SELECT id, ext, width, height FROM photos WHERE listing_id = ? ORDER BY position LIMIT 1').get(l.id);
  return {
    id: l.id,
    title: l.title,
    brand: { slug: l.brand_slug, name: l.brand_name },
    category: l.category,
    categoryName: CATEGORY_NAME[l.category] || l.category,
    size: l.size,
    condition: COND_NAME[l.condition] || l.condition,
    price: l.price,
    negotiable: !!l.negotiable,
    hasProof: !!l.has_proof,
    status: l.status,
    photo: photo ? { url: photoUrl(photo), thumb: photoUrl(photo, true), w: photo.width, h: photo.height } : null,
    seller: { username: l.seller_name, avatar: avatarUrl(l.seller_avatar) },
    favorites: l.fav_count ?? 0,
    createdAt: l.created_at,
  };
}

const LISTING_SELECT = `
  SELECT l.*, b.name AS brand_name, u.username AS seller_name, u.avatar_id AS seller_avatar,
         (SELECT COUNT(*) FROM favorites f WHERE f.listing_id = l.id) AS fav_count
  FROM listings l JOIN brands b ON b.slug = l.brand_slug JOIN users u ON u.id = l.seller_id`;

function brandsWithCounts() {
  return db.prepare(`SELECT b.slug, b.name, b.origin, b.grp AS "group", b.user_added,
      (SELECT COUNT(*) FROM listings l WHERE l.brand_slug = b.slug AND l.status = 'active') AS count
    FROM brands b ORDER BY b.name COLLATE NOCASE`).all();
}

function sellerStats(userId) {
  const c = db.prepare(`SELECT
      SUM(status = 'active') AS active, SUM(status = 'sold') AS sold, SUM(status IN ('active','sold')) AS total
    FROM listings WHERE seller_id = ?`).get(userId);
  const r = db.prepare('SELECT AVG(rating) AS avg, COUNT(*) AS n FROM reviews WHERE seller_id = ?').get(userId);
  return { active: c.active || 0, sold: c.sold || 0, total: c.total || 0, rating: r.n ? Math.round(r.avg * 10) / 10 : null, reviews: r.n };
}

function publicUser(u) {
  return { username: u.username, bio: u.bio, city: u.city, avatar: avatarUrl(u.avatar_id), createdAt: u.created_at, stats: sellerStats(u.id) };
}

/* ---------- Validation d'une annonce ---------- */
function resolveBrand(body, user) {
  const slug = str(body.brand, 60);
  if (slug && db.prepare('SELECT 1 FROM brands WHERE slug = ?').get(slug)) return slug;
  const name = str(body.brandName, 60);
  if (!name || name.length < 2) fail(400, 'Please enter the brand.');
  const s = slugify(name);
  if (!s) fail(400, 'Invalid brand name.');
  const existing = db.prepare('SELECT slug FROM brands WHERE slug = ? OR name = ? COLLATE NOCASE').get(s, name);
  if (existing) return existing.slug;
  db.prepare('INSERT INTO brands (slug, name, user_added, created_by, created_at) VALUES (?, ?, 1, ?, ?)').run(s, name, user.id, now());
  return s;
}

function validateListing(body, user, listingId = null) {
  const title = str(body.title, 120);
  const category = str(body.category, 30);
  const size = str(body.size, 20);
  const condition = str(body.condition, 30);
  const price = Math.round(Number(body.price));
  const description = str(body.description, 4000);
  const colors = Array.isArray(body.colors) ? [...new Set(body.colors.filter((c) => COLORS[c]))].slice(0, 4) : [];
  const photoIds = Array.isArray(body.photoIds) ? body.photoIds.map((x) => str(x, 40)).slice(0, 12) : [];
  if (title.length < 3) fail(400, 'The product name is too short.');
  if (!CATEGORY_NAME[category]) fail(400, 'Please choose a category.');
  if (!size) fail(400, 'Please enter the size.');
  if (!COND_NAME[condition]) fail(400, 'Please choose the condition.');
  if (!Number.isFinite(price) || price < 1 || price > 1000000) fail(400, 'Invalid price (between €1 and €1,000,000).');
  if (description.length < 20) fail(400, 'Describe the item in at least 20 characters.');
  if (!photoIds.length) fail(400, 'Add at least one real photo of the item.');
  if (!bool(body.certify)) fail(400, 'Please confirm the photos are yours and show the item for sale.');
  for (const id of photoIds) {
    const p = db.prepare('SELECT owner_id, listing_id FROM photos WHERE id = ?').get(id);
    if (!p || p.owner_id !== user.id || (p.listing_id && p.listing_id !== listingId)) fail(400, 'Invalid photo.');
  }
  const brand = resolveBrand(body, user);
  return { brand, title, category, size, condition, price, description, colors, photoIds, negotiable: bool(body.negotiable), hasProof: bool(body.hasProof) };
}

function attachPhotos(listingId, ids) {
  db.prepare('UPDATE photos SET listing_id = NULL WHERE listing_id = ?').run(listingId);
  const upd = db.prepare('UPDATE photos SET listing_id = ?, position = ? WHERE id = ?');
  ids.forEach((id, i) => upd.run(listingId, i, id));
}

/* ---------- Recherche (base de données) ---------- */
function searchListings(q) {
  const where = ["l.status = 'active'"];
  const args = [];
  const terms = normText(q.q || '').split(' ').filter((t) => t.length > 0).slice(0, 8);
  for (const t of terms) { where.push('l.search_text LIKE ?'); args.push(`%${t}%`); }
  if (q.brand) { where.push('l.brand_slug = ?'); args.push(q.brand); }
  if (q.category) { where.push('l.category = ?'); args.push(q.category); }
  if (q.size) { where.push('l.size = ? COLLATE NOCASE'); args.push(q.size); }
  if (q.condition) { where.push('l.condition = ?'); args.push(q.condition); }
  if (q.color && COLORS[q.color]) { where.push('l.colors LIKE ?'); args.push(`%"${q.color}"%`); }
  if (q.seller) { where.push('u.username = ? COLLATE NOCASE'); args.push(q.seller); }
  if (Number(q.min) > 0) { where.push('l.price >= ?'); args.push(Number(q.min)); }
  if (Number(q.max) > 0) { where.push('l.price <= ?'); args.push(Number(q.max)); }
  const order = {
    'price-asc': 'l.price ASC, l.created_at DESC',
    'price-desc': 'l.price DESC, l.created_at DESC',
    popular: '(fav_count * 3 + l.views) DESC, l.created_at DESC',
  }[q.sort] || 'l.created_at DESC';
  const pageSize = 36;
  const page = Math.max(1, Math.floor(Number(q.page)) || 1);
  const base = `FROM listings l JOIN brands b ON b.slug = l.brand_slug JOIN users u ON u.id = l.seller_id WHERE ${where.join(' AND ')}`;
  const total = db.prepare(`SELECT COUNT(*) AS n ${base}`).get(...args).n;
  const rows = db.prepare(`${LISTING_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...args, pageSize, (page - 1) * pageSize);
  return { total, page, pageSize, items: rows.map(card) };
}

function facets(q) {
  const where = ["status = 'active'"];
  const args = [];
  if (q.brand) { where.push('brand_slug = ?'); args.push(q.brand); }
  const w = where.join(' AND ');
  return {
    categories: db.prepare(`SELECT category AS slug, COUNT(*) AS count FROM listings WHERE ${w} GROUP BY category`).all(...args),
    sizes: db.prepare(`SELECT size, COUNT(*) AS count FROM listings WHERE ${w} GROUP BY size COLLATE NOCASE ORDER BY size`).all(...args),
    price: db.prepare(`SELECT MIN(price) AS min, MAX(price) AS max FROM listings WHERE ${w}`).get(...args),
  };
}

/* ---------- Recherche par image : annonces actives ---------- */
function activeForRanking() {
  return db.prepare(`SELECT l.id, l.brand_slug, b.name AS brandName, l.title, l.category, l.colors, l.description, l.size, l.price
    FROM listings l JOIN brands b ON b.slug = l.brand_slug WHERE l.status = 'active'`).all()
    .map((l) => ({ ...l, colors: JSON.parse(l.colors), categoryName: CATEGORY_NAME[l.category] }));
}
function rankedCards(item, mode, limit, exclude = new Set(), pool = activeForRanking()) {
  const hits = rank(pool, item, { mode, limit: limit + exclude.size }).filter((h) => !exclude.has(h.id)).slice(0, limit);
  const get = db.prepare(`${LISTING_SELECT} WHERE l.id = ?`);
  return hits.map((h) => ({ ...card(get.get(h.id)), similarity: h.similarity }));
}
/** EXACT MATCHES + SIMILAR FINDS (similar excludes what is already an exact match). */
function bothSections(item) {
  const pool = activeForRanking();
  const exact = rankedCards(item, 'exact', 24, new Set(), pool);
  const similar = rankedCards(item, 'similar', 36, new Set(exact.map((e) => e.id)), pool);
  return { exact, similar };
}

/* AI status: honest about whether image recognition is actually connected. */
let aiState = process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_AUTH_TOKEN ? 'configured' : 'not-configured';
function visionRef() {
  return { categories: CATEGORIES, brands: db.prepare('SELECT slug, name FROM brands ORDER BY name').all(), colors: COLORS };
}
function sanitizeItem(it = {}) {
  const list = (a, n = 20) => (Array.isArray(a) ? a.slice(0, n).map((s) => str(s, 80)).filter(Boolean) : []);
  return {
    category: CATEGORY_NAME[it.category] ? it.category : '',
    label: str(it.label, 120),
    brand: it.brand && db.prepare('SELECT 1 FROM brands WHERE slug = ?').get(String(it.brand)) ? String(it.brand) : 'unknown',
    brand_other: str(it.brand_other, 80),
    brand_confidence: Math.max(0, Math.min(1, Number(it.brand_confidence) || 0)),
    brand_evidence: str(it.brand_evidence, 300),
    model: str(it.model, 80),
    colors: list(it.colors, 5).filter((c) => COLORS[c]),
    fit: str(it.fit, 60),
    materials: list(it.materials), details: list(it.details), patterns: list(it.patterns),
    logos_text: list(it.logos_text), keywords: list(it.keywords),
  };
}

/* ---------- WANTED : prévenir quand une annonce correspondante est publiée ---------- */
function notifyWanted(listingId) {
  const l = db.prepare(`${LISTING_SELECT} WHERE l.id = ?`).get(listingId);
  if (!l || l.status !== 'active') return;
  const target = [{ id: l.id, brand_slug: l.brand_slug, brandName: l.brand_name, title: l.title, category: l.category, colors: JSON.parse(l.colors), description: l.description, categoryName: CATEGORY_NAME[l.category] }];
  const ins = db.prepare('INSERT INTO notifications (id, user_id, title, body, href, created_at) VALUES (?, ?, ?, ?, ?, ?)');
  for (const w of db.prepare('SELECT * FROM wanted WHERE user_id != ?').all(l.seller_id)) {
    if (w.max_price && l.price > w.max_price) continue;
    if (w.size && normText(w.size) !== normText(l.size)) continue;
    const [hit] = rank(target, JSON.parse(w.criteria), { mode: 'similar', limit: 1 });
    if (hit && hit.similarity >= 70) {
      ins.run(randomUUID(), w.user_id, `WANTED · ${w.label}`, `${l.brand_name} · ${l.title} was just listed (€${l.price}).`, `item.html?id=${l.id}`, now());
    }
  }
}

/* ---------- Photos ---------- */
const MAGIC = { 'image/jpeg': [[0xff, 0xd8, 0xff], 'jpg'], 'image/png': [[0x89, 0x50, 0x4e, 0x47], 'png'], 'image/webp': [[0x52, 0x49, 0x46, 0x46], 'webp'] };
function decodeImage(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) fail(400, 'Unsupported photo format (JPEG, PNG or WebP).');
  const buf = Buffer.from(m[2], 'base64');
  const [sig, ext] = MAGIC[m[1]];
  if (!sig.every((b, i) => buf[i] === b)) fail(400, 'Invalid image file.');
  return { buf, ext };
}

/* ---------- Routes ---------- */
async function api(req, res, path, url) {
  const method = req.method;
  const me = currentUser(db, req);
  const q = Object.fromEntries(url.searchParams);
  // Protection CSRF : toute écriture doit venir de notre JavaScript (en-tête personnalisé).
  if (method !== 'GET' && req.headers['x-ff-request'] !== '1') fail(403, 'Request refused.');
  const auth = () => me || fail(401, 'Please sign in to continue.');
  let m;

  /* Référentiel */
  if (method === 'GET' && path === '/api/reference') {
    return send(res, 200, { categories: CATEGORIES, sizes: SIZES, conditions: CONDITIONS, colors: COLORS, brands: brandsWithCounts() });
  }

  /* Comptes */
  if (method === 'GET' && path === '/api/me') {
    if (!me) return send(res, 200, { user: null });
    const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND seen = 0').get(me.id).n;
    return send(res, 200, { user: { ...publicUser(me), email: me.email, unread } });
  }
  if (method === 'POST' && path === '/api/auth/signup') {
    if (!rateLimit(`signup:${ip(req)}`, 10, 3600000)) fail(429, 'Too many attempts, please try again later.');
    const b = await readBody(req);
    const username = str(b.username, 24);
    const email = str(b.email, 120).toLowerCase();
    const password = String(b.password || '');
    if (!/^[a-zA-Z0-9._-]{3,24}$/.test(username)) fail(400, 'Username: 3 to 24 characters (letters, numbers, . _ -).');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'Invalid email address.');
    if (password.length < 8) fail(400, 'Password: 8 characters minimum.');
    if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) fail(409, 'This username is already taken.');
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) fail(409, 'An account already exists with this email.');
    const info = db.prepare('INSERT INTO users (username, email, pass_hash, created_at) VALUES (?, ?, ?, ?)').run(username, email, await hashPassword(password), now());
    const token = createSession(db, Number(info.lastInsertRowid));
    return send(res, 201, { ok: true }, { 'Set-Cookie': sessionCookie(token, SECURE) });
  }
  if (method === 'POST' && path === '/api/auth/login') {
    if (!rateLimit(`login:${ip(req)}`, 10, 600000)) fail(429, 'Too many attempts, please try again in 10 minutes.');
    const b = await readBody(req);
    const login = str(b.login, 120);
    const u = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(login, login.toLowerCase());
    if (!u || !(await verifyPassword(String(b.password || ''), u.pass_hash))) fail(401, 'Incorrect username/email or password.');
    const token = createSession(db, u.id);
    return send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie(token, SECURE) });
  }
  if (method === 'POST' && path === '/api/auth/logout') {
    destroySession(db, readCookie(req));
    return send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie(null, SECURE) });
  }
  if (method === 'PATCH' && path === '/api/me') {
    const u = auth();
    const b = await readBody(req);
    let avatar = u.avatar_id;
    if (b.avatarId !== undefined) {
      const p = b.avatarId ? db.prepare('SELECT owner_id, listing_id FROM photos WHERE id = ?').get(str(b.avatarId, 40)) : null;
      if (b.avatarId && (!p || p.owner_id !== u.id || p.listing_id)) fail(400, 'Invalid profile photo.');
      avatar = b.avatarId || null;
    }
    db.prepare('UPDATE users SET bio = ?, city = ?, avatar_id = ? WHERE id = ?').run(str(b.bio ?? u.bio, 600), str(b.city ?? u.city, 60), avatar, u.id);
    return send(res, 200, { ok: true });
  }

  /* Photos (importées depuis l'appareil du vendeur) */
  if (method === 'POST' && path === '/api/photos') {
    const u = auth();
    if (!rateLimit(`photo:${u.id}`, 80, 600000)) fail(429, 'Too many photos uploaded, please wait a few minutes.');
    const b = await readBody(req, 24 * 1024 * 1024);
    const full = decodeImage(b.full);
    const thumb = decodeImage(b.thumb);
    const w = Math.round(Number(b.width)), h = Math.round(Number(b.height));
    if (!(w > 0 && h > 0 && w <= 4096 && h <= 4096)) fail(400, 'Invalid photo dimensions.');
    const minPx = b.purpose === 'avatar' ? 200 : 600;
    if (w < minPx && h < minPx) fail(400, `Photo too small: ${minPx} px minimum for a sharp image.`);
    const id = randomBytes(12).toString('base64url');
    await writeFile(join(UPLOADS, `${id}.${full.ext}`), full.buf);
    await writeFile(join(UPLOADS, `${id}_t.${full.ext}`), thumb.buf);
    db.prepare('INSERT INTO photos (id, owner_id, width, height, ext, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(id, u.id, w, h, full.ext, now());
    return send(res, 201, { id, url: `/uploads/${id}.${full.ext}`, thumb: `/uploads/${id}_t.${full.ext}`, width: w, height: h });
  }

  /* Marques */
  if (method === 'GET' && path === '/api/brands') return send(res, 200, brandsWithCounts());
  if (method === 'GET' && (m = /^\/api\/brands\/([\w-]+)$/.exec(path))) {
    const b = brandsWithCounts().find((x) => x.slug === m[1]);
    return b ? send(res, 200, b) : fail(404, 'Brand not found.');
  }

  /* Annonces */
  if (method === 'GET' && path === '/api/listings') return send(res, 200, searchListings(q));
  if (method === 'GET' && path === '/api/facets') return send(res, 200, facets(q));
  if (method === 'POST' && path === '/api/listings') {
    const u = auth();
    if (!rateLimit(`list:${u.id}`, 30, 3600000)) fail(429, 'Too many listings published in a short time.');
    const v = validateListing(await readBody(req), u);
    const id = randomBytes(6).toString('base64url');
    const t = now();
    const brandName = db.prepare('SELECT name FROM brands WHERE slug = ?').get(v.brand).name;
    db.prepare(`INSERT INTO listings (id, seller_id, brand_slug, title, category, size, condition, price, negotiable, has_proof, description, colors, search_text, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, u.id, v.brand, v.title, v.category, v.size, v.condition, v.price, v.negotiable, v.hasProof, v.description, JSON.stringify(v.colors), searchText(v, brandName), t, t);
    attachPhotos(id, v.photoIds);
    notifyWanted(id);
    return send(res, 201, { id });
  }
  if ((m = /^\/api\/listings\/([\w-]+)$/.exec(path))) {
    const l = db.prepare(`${LISTING_SELECT} WHERE l.id = ?`).get(m[1]);
    if (!l || (l.status === 'removed' && (!me || me.id !== l.seller_id))) fail(404, 'Listing not found.');
    const owner = me && me.id === l.seller_id;
    if (method === 'GET') {
      if (!owner) db.prepare('UPDATE listings SET views = views + 1 WHERE id = ?').run(l.id);
      const photos = db.prepare('SELECT id, ext, width, height FROM photos WHERE listing_id = ? ORDER BY position').all(l.id)
        .map((p) => ({ id: p.id, url: photoUrl(p), thumb: photoUrl(p, true), w: p.width, h: p.height }));
      const seller = db.prepare('SELECT * FROM users WHERE id = ?').get(l.seller_id);
      return send(res, 200, {
        ...card(l),
        condition: COND_NAME[l.condition], conditionSlug: l.condition, brandSlug: l.brand_slug,
        description: l.description, colors: JSON.parse(l.colors), views: l.views, photos,
        seller: publicUser(seller), isOwner: !!owner,
        isFavorite: !!(me && db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND listing_id = ?').get(me.id, l.id)),
        soldTo: owner && l.buyer_id ? db.prepare('SELECT username FROM users WHERE id = ?').get(l.buyer_id)?.username : undefined,
      });
    }
    if (method === 'PATCH') {
      const u = auth();
      if (u.id !== l.seller_id) fail(403, 'This is not your listing.');
      const v = validateListing(await readBody(req), u, l.id);
      const brandName = db.prepare('SELECT name FROM brands WHERE slug = ?').get(v.brand).name;
      db.prepare(`UPDATE listings SET brand_slug=?, title=?, category=?, size=?, condition=?, price=?, negotiable=?, has_proof=?, description=?, colors=?, search_text=?, updated_at=? WHERE id=?`)
        .run(v.brand, v.title, v.category, v.size, v.condition, v.price, v.negotiable, v.hasProof, v.description, JSON.stringify(v.colors), searchText(v, brandName), now(), l.id);
      attachPhotos(l.id, v.photoIds);
      return send(res, 200, { id: l.id });
    }
  }
  if (method === 'POST' && (m = /^\/api\/listings\/([\w-]+)\/status$/.exec(path))) {
    const u = auth();
    const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(m[1]);
    if (!l || l.seller_id !== u.id) fail(404, 'Listing not found.');
    const b = await readBody(req);
    const status = b.status;
    if (!['active', 'sold', 'removed'].includes(status)) fail(400, 'Invalid status.');
    let buyer = null;
    if (status === 'sold' && b.buyer) {
      buyer = db.prepare('SELECT id FROM users WHERE username = ?').get(str(b.buyer, 24));
      if (!buyer) fail(400, 'Buyer not found: check their username.');
      if (buyer.id === u.id) fail(400, 'You cannot be your own buyer.');
    }
    db.prepare('UPDATE listings SET status = ?, buyer_id = ?, sold_at = ?, updated_at = ? WHERE id = ?')
      .run(status, status === 'sold' ? buyer?.id ?? null : null, status === 'sold' ? now() : null, now(), l.id);
    if (buyer) {
      db.prepare('INSERT INTO notifications (id, user_id, title, body, href, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        .run(randomUUID(), buyer.id, 'Purchase confirmed', `${u.username} confirmed your purchase of “${l.title}”. You can now leave a review.`, 'account.html#purchases', now());
    }
    if (status === 'active' && l.status !== 'active') notifyWanted(l.id);
    return send(res, 200, { ok: true });
  }
  if (method === 'POST' && (m = /^\/api\/listings\/([\w-]+)\/favorite$/.exec(path))) {
    const u = auth();
    if (!db.prepare("SELECT 1 FROM listings WHERE id = ? AND status != 'removed'").get(m[1])) fail(404, 'Listing not found.');
    const had = db.prepare('SELECT 1 FROM favorites WHERE user_id = ? AND listing_id = ?').get(u.id, m[1]);
    if (had) db.prepare('DELETE FROM favorites WHERE user_id = ? AND listing_id = ?').run(u.id, m[1]);
    else db.prepare('INSERT INTO favorites (user_id, listing_id, created_at) VALUES (?, ?, ?)').run(u.id, m[1], now());
    const count = db.prepare('SELECT COUNT(*) AS n FROM favorites WHERE listing_id = ?').get(m[1]).n;
    return send(res, 200, { favorite: !had, count });
  }

  /* Espace personnel */
  if (method === 'GET' && path === '/api/me/listings') {
    const u = auth();
    return send(res, 200, db.prepare(`${LISTING_SELECT} WHERE l.seller_id = ? AND l.status != 'removed' ORDER BY l.created_at DESC`).all(u.id)
      .map((l) => ({ ...card(l), views: l.views, buyer: l.buyer_id ? db.prepare('SELECT username FROM users WHERE id = ?').get(l.buyer_id)?.username : null })));
  }
  if (method === 'GET' && path === '/api/me/favorites') {
    const u = auth();
    return send(res, 200, db.prepare(`${LISTING_SELECT} JOIN favorites f ON f.listing_id = l.id WHERE f.user_id = ? AND l.status != 'removed' ORDER BY f.created_at DESC`).all(u.id).map(card));
  }
  if (method === 'GET' && path === '/api/me/purchases') {
    const u = auth();
    return send(res, 200, db.prepare(`${LISTING_SELECT} WHERE l.buyer_id = ? ORDER BY l.sold_at DESC`).all(u.id)
      .map((l) => ({ ...card(l), reviewed: !!db.prepare('SELECT 1 FROM reviews WHERE listing_id = ?').get(l.id) })));
  }

  /* Profils vendeurs */
  if (method === 'GET' && (m = /^\/api\/users\/([\w.-]+)$/.exec(path))) {
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(m[1]);
    if (!u) fail(404, 'Seller not found.');
    const listings = (status) => db.prepare(`${LISTING_SELECT} WHERE l.seller_id = ? AND l.status = ? ORDER BY COALESCE(l.sold_at, l.created_at) DESC LIMIT 120`).all(u.id, status).map(card);
    const reviews = db.prepare(`SELECT r.rating, r.comment, r.created_at, b.username AS buyer, l.title
      FROM reviews r JOIN users b ON b.id = r.buyer_id JOIN listings l ON l.id = r.listing_id WHERE r.seller_id = ? ORDER BY r.created_at DESC`).all(u.id);
    return send(res, 200, { ...publicUser(u), active: listings('active'), sold: listings('sold'), reviews, isMe: !!(me && me.id === u.id) });
  }

  /* Avis : uniquement l'acheteur désigné par le vendeur, une fois par article */
  if (method === 'POST' && path === '/api/reviews') {
    const u = auth();
    const b = await readBody(req);
    const l = db.prepare('SELECT * FROM listings WHERE id = ?').get(str(b.listingId, 40));
    if (!l || l.status !== 'sold' || l.buyer_id !== u.id) fail(403, 'Only the buyer of this item can leave a review.');
    if (db.prepare('SELECT 1 FROM reviews WHERE listing_id = ?').get(l.id)) fail(409, 'You have already reviewed this purchase.');
    const rating = Math.round(Number(b.rating));
    if (!(rating >= 1 && rating <= 5)) fail(400, 'Rating must be between 1 and 5.');
    db.prepare('INSERT INTO reviews (listing_id, seller_id, buyer_id, rating, comment, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(l.id, l.seller_id, u.id, rating, str(b.comment, 1000), now());
    return send(res, 201, { ok: true });
  }

  /* Recherche par image */
  if (method === 'POST' && path === '/api/visual-search') {
    if (!rateLimit(`vs:${ip(req)}`, 20, 600000)) fail(429, 'Too many searches, please wait a few minutes.');
    const b = await readBody(req, 16 * 1024 * 1024);
    const m2 = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(b.image || '');
    if (!m2) fail(400, 'Invalid image: JPEG, PNG, WebP or GIF expected.');
    try {
      const t0 = Date.now();
      const analysis = await analyzeImage(visionRef(), { mediaType: m2[1], data: m2[2] });
      aiState = 'connected';
      const items = (analysis.items || []).map(sanitizeItem);
      return send(res, 200, {
        engine: 'ai', model: analysis.model || MODEL, ms: Date.now() - t0, isFashion: !!analysis.is_fashion,
        summary: str(analysis.summary, 600), items, ...(items.length ? bothSections(items[0]) : { exact: [], similar: [] }),
      });
    } catch (e) {
      if (e instanceof VisionUnavailable) {
        aiState = 'unavailable';
        return send(res, 503, { error: 'ai-unavailable', message: 'AI image recognition is not connected on this server (no Anthropic API key configured).', detail: e.message });
      }
      throw e;
    }
  }
  // Re-ranking without a new AI call (other detected item, or color-only fallback)
  if (method === 'POST' && path === '/api/rank') {
    const b = await readBody(req);
    return send(res, 200, bothSections(sanitizeItem(b.item)));
  }
  if (method === 'GET' && path === '/api/status') {
    return send(res, 200, { ai: aiState, model: MODEL, listings: db.prepare("SELECT COUNT(*) AS n FROM listings WHERE status = 'active'").get().n });
  }

  /* WANTED ITEMS */
  if (path === '/api/wanted') {
    const u = auth();
    if (method === 'GET') {
      const listings = activeForRanking().filter((l) => true);
      return send(res, 200, db.prepare('SELECT * FROM wanted WHERE user_id = ? ORDER BY created_at DESC').all(u.id).map((w) => {
        const crit = JSON.parse(w.criteria);
        const matches = rank(listings, crit, { mode: 'similar', limit: 8 }).filter((h) => h.similarity >= 70);
        const get = db.prepare(`${LISTING_SELECT} WHERE l.id = ?`);
        return {
          id: w.id, label: w.label, thumb: w.thumb, size: w.size, maxPrice: w.max_price, createdAt: w.created_at, criteria: crit,
          matches: matches.map((h) => ({ ...card(get.get(h.id)), similarity: h.similarity }))
            .filter((c) => (!w.max_price || c.price <= w.max_price) && (!w.size || normText(w.size) === normText(c.size))),
        };
      }));
    }
    if (method === 'POST') {
      const b = await readBody(req, 512 * 1024);
      const id = randomUUID();
      const thumb = typeof b.thumb === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(b.thumb) && b.thumb.length < 200000 ? b.thumb : null;
      db.prepare('INSERT INTO wanted (id, user_id, label, criteria, thumb, size, max_price, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
        .run(id, u.id, str(b.label, 120) || 'Wanted item', JSON.stringify(sanitizeItem(b.criteria)), thumb, str(b.size, 20), Number(b.maxPrice) > 0 ? Math.round(Number(b.maxPrice)) : null, now());
      return send(res, 201, { id, label: str(b.label, 120) || 'Wanted item' });
    }
  }
  if (method === 'DELETE' && (m = /^\/api\/wanted\/([\w-]+)$/.exec(path))) {
    const u = auth();
    db.prepare('DELETE FROM wanted WHERE id = ? AND user_id = ?').run(m[1], u.id);
    return send(res, 204);
  }

  /* Notifications */
  if (method === 'GET' && path === '/api/notifications') {
    if (!me) return send(res, 200, []);
    return send(res, 200, db.prepare('SELECT id, title, body, href, created_at FROM notifications WHERE user_id = ? AND seen = 0 ORDER BY created_at DESC LIMIT 20').all(me.id));
  }
  if (method === 'POST' && path === '/api/notifications/seen') {
    const u = auth();
    const { ids = [] } = await readBody(req);
    const upd = db.prepare('UPDATE notifications SET seen = 1 WHERE id = ? AND user_id = ?');
    for (const id of ids.slice(0, 50)) upd.run(String(id), u.id);
    return send(res, 204);
  }

  fail(404, 'Unknown route.');
}

/* ---------- Serveur ---------- */
createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  let path;
  try { path = decodeURIComponent(url.pathname); } catch { return send(res, 400, { error: 'Invalid URL.' }); }
  try {
    if (path.startsWith('/api/')) return await api(req, res, path, url);
    let file;
    if (path.startsWith('/uploads/')) {
      if (!/^\/uploads\/[\w-]+(_t)?\.(jpg|png|webp)$/.test(path)) return send(res, 404, { error: '404' });
      file = join(UPLOADS, path.slice('/uploads/'.length));
    } else {
      file = normalize(join(ROOT, path.endsWith('/') ? `${path}index.html` : path));
      const rel = file.slice(ROOT.length);
      if (!file.startsWith(ROOT) || /^[\\/](server|tools|node_modules|data|docs|\.claude)([\\/]|$)/.test(rel) || /package(-lock)?\.json$/.test(rel)) {
        return send(res, 403, { error: 'Forbidden.' });
      }
    }
    const data = await readFile(file);
    res.writeHead(200, {
      'Content-Type': TYPES[extname(file)] || 'application/octet-stream',
      'Cache-Control': path.startsWith('/uploads/') ? 'public, max-age=31536000, immutable' : 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(data);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    if (e.code === 'ENOENT' || e.code === 'EISDIR') return send(res, 404, { error: 'Page not found.' });
    console.error(e);
    send(res, 500, { error: 'Server error.' });
  }
}).listen(PORT, () => console.log(`Fashion Find : http://localhost:${PORT}  (vision : ${MODEL})`));
