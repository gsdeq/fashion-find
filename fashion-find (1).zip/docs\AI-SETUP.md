# Search by Image: AI setup

Search by Image works in two layers:

1. **Recognition (external AI).** The screenshot is sent from the server to Claude (Anthropic API, vision).
   Claude returns structured JSON for each garment it sees: category, possible brand + confidence + the visual
   evidence, model (only when it recognises it with confidence), colors, cut, materials, details, patterns, readable logos,
   and keywords. Code: `server/vision.mjs`.
2. **Matching (Fashion Find database).** Those attributes are scored against every active listing in the
   SQLite database (category, brand, colors, words of the title and description). This produces the two sections
   **EXACT MATCHES** (same category + same brand + model/details + compatible color) and **SIMILAR FINDS**
   with an estimated similarity percentage. Code: `server/search.mjs`.

## Until the AI is connected

Without credentials the site says so: the badge on the Search by Image page reads
**"AI not connected · color matching only"**, and results use only the colors measured in the screenshot plus the type of
item the user picks. Exact matching is disabled. Nothing is presented as AI recognition.

`GET /api/status` returns `ai`: `not-configured`, `configured`, `connected` (a call succeeded) or `unavailable` (a call failed
for credential or network reasons).

## What to configure

| Variable | Required | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | yes | API key from console.anthropic.com. Kept on the server only, never sent to the browser. |
| `FF_VISION_MODEL` | no | Model ID. Default: `claude-opus-5-5`. |
| `PORT` | no | Server port. Default: `8090`. |
| `FF_SECURE_COOKIE` | in production | Set to `1` behind HTTPS so session cookies get the `Secure` flag. |

Windows PowerShell:

```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-..."
npm start
```

macOS / Linux:

```bash
ANTHROPIC_API_KEY=sk-ant-... npm start
```

Notes:
- Requests use refusal fallbacks (`fallbacks: "default"`), so if the model declines an image the API retries it on a fallback model automatically.
- Each search is one API call with the image, billed by Anthropic. The server limits searches to 20 per IP per 10 minutes (`server/index.mjs`).
- Screenshots are resized to 1568 px in the browser before upload and are not stored on the server.

## Next step for scale: visual embeddings

Attribute matching depends on what sellers write. To compare the screenshot with the **photos** of each listing,
add an image-embedding index:

1. When a listing is published, compute an embedding of its main photo (e.g. a CLIP / SigLIP / FashionCLIP model,
   self-hosted or via an embeddings API) and store it (pgvector, Qdrant, or SQLite + `sqlite-vec`).
2. At search time, embed the screenshot (or the crop of each detected item) and fetch the nearest listings.
3. Pass the cosine scores to `rank(listings, item, { visual })` in `server/search.mjs`: the ranking already blends
   them (60 % attributes, 40 % visual) when the `visual` map is provided.
