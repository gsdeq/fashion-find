// FASHION FIND — base de données SQLite (module node:sqlite intégré à Node).
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { BRANDS, CATEGORIES, COLORS } from './reference.mjs';

export function openDb(dataDir) {
  mkdirSync(dataDir, { recursive: true });
  const db = new DatabaseSync(join(dataDir, 'fashion-find.db'));
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      pass_hash TEXT NOT NULL,
      bio TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT '',
      avatar_id TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS brands (
      slug TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      origin TEXT NOT NULL DEFAULT '',
      grp TEXT NOT NULL DEFAULT 'designer',
      user_added INTEGER NOT NULL DEFAULT 0,
      created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS listings (
      id TEXT PRIMARY KEY,
      seller_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      brand_slug TEXT NOT NULL REFERENCES brands(slug),
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      size TEXT NOT NULL,
      condition TEXT NOT NULL,
      price INTEGER NOT NULL,
      negotiable INTEGER NOT NULL DEFAULT 0,
      has_proof INTEGER NOT NULL DEFAULT 0,
      description TEXT NOT NULL,
      colors TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'active',
      views INTEGER NOT NULL DEFAULT 0,
      search_text TEXT NOT NULL DEFAULT '',
      buyer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      sold_at TEXT
    );
    CREATE INDEX IF NOT EXISTS listings_status_created ON listings(status, created_at DESC);
    CREATE INDEX IF NOT EXISTS listings_brand ON listings(brand_slug, status);
    CREATE INDEX IF NOT EXISTS listings_seller ON listings(seller_id, status);

    CREATE TABLE IF NOT EXISTS photos (
      id TEXT PRIMARY KEY,
      owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      listing_id TEXT REFERENCES listings(id) ON DELETE SET NULL,
      position INTEGER NOT NULL DEFAULT 0,
      width INTEGER NOT NULL,
      height INTEGER NOT NULL,
      ext TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS photos_listing ON photos(listing_id, position);

    CREATE TABLE IF NOT EXISTS favorites (
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      listing_id TEXT NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL,
      PRIMARY KEY (user_id, listing_id)
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY,
      listing_id TEXT NOT NULL UNIQUE REFERENCES listings(id) ON DELETE CASCADE,
      seller_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      buyer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
      comment TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wanted (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      label TEXT NOT NULL,
      criteria TEXT NOT NULL,
      thumb TEXT,
      size TEXT NOT NULL DEFAULT '',
      max_price INTEGER,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      href TEXT NOT NULL DEFAULT '',
      seen INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);

  const now = new Date().toISOString();
  // Reference brands: inserted, or refreshed if their name/origin/group changed.
  const ins = db.prepare(`INSERT INTO brands (slug, name, origin, grp, user_added, created_at) VALUES (?, ?, ?, ?, 0, ?)
    ON CONFLICT(slug) DO UPDATE SET name = excluded.name, origin = excluded.origin, grp = excluded.grp WHERE brands.user_added = 0`);
  for (const [slug, name, origin, grp] of BRANDS) ins.run(slug, name, origin, grp, now);
  return db;
}

export const CATEGORY_NAME = Object.fromEntries(CATEGORIES.map((c) => [c.slug, c.name]));

export function normText(...parts) {
  return parts.flat().join(' ').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
}

/** Texte indexé pour la recherche plein texte d'une annonce. */
export function searchText(l, brandName) {
  const colors = (Array.isArray(l.colors) ? l.colors : JSON.parse(l.colors || '[]')).map((c) => COLORS[c]?.name || c);
  return normText(brandName, l.title, CATEGORY_NAME[l.category] || l.category, l.size, colors, l.description);
}
