/* FASHION FIND — shared behaviour: API helper, account state, navigation, loader, notifications. */
(function () {
  var ICON = 'assets/brand/icon-192.png';
  var BADGE = 'assets/brand/badge-96.png';
  var CAMERA = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>';
  var BELL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M6 9a6 6 0 1 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9Z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ---------- API ---------- */
  function api(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || 'GET', headers: {}, credentials: 'same-origin' };
    if (init.method !== 'GET') init.headers['X-FF-Request'] = '1';
    if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
    return fetch(path, init).then(function (r) {
      if (r.status === 204) return null;
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) { var e = new Error(j.message || j.error || 'Something went wrong.'); e.status = r.status; e.data = j; throw e; }
        return j;
      });
    });
  }

  var mePromise = null;
  function me(refresh) {
    if (!mePromise || refresh) mePromise = api('/api/me').then(function (r) { return r.user; }).catch(function () { return null; });
    return mePromise;
  }
  /** Redirects to sign-in when the visitor is not logged in. */
  function requireMe() {
    return me().then(function (u) {
      if (!u) { location.href = 'login.html?next=' + encodeURIComponent(location.pathname.replace(/^\//, '') + location.search + location.hash); throw new Error('auth'); }
      return u;
    });
  }

  /* ---------- Navigation (same on every page) ---------- */
  function initNav() {
    var nav = document.querySelector('[data-ff-nav]');
    if (!nav) return;
    var active = nav.getAttribute('data-ff-nav');
    var links = [['shop', 'shop.html', 'Shop'], ['designers', 'designers.html', 'Designers'], ['wanted', 'wanted.html', 'Wanted']];
    nav.classList.add('ff-nav');
    nav.innerHTML =
      '<a class="ff-brand" href="index.html" aria-label="Fashion Find home">' +
        '<img class="ff-brand__mark" src="assets/brand/ff-emblem.svg" alt="">' +
        '<img class="ff-brand__word" src="assets/brand/ff-wordmark-white.svg" alt="FASHION FIND">' +
      '</a>' +
      '<nav class="ff-nav__links label" aria-label="Main">' +
        links.map(function (l) { return '<a href="' + l[1] + '"' + (l[0] === active ? ' aria-current="page"' : '') + '>' + l[2] + '</a>'; }).join('') +
        '<a href="sell.html"' + (active === 'sell' ? ' aria-current="page"' : '') + '>Sell</a>' +
      '</nav>' +
      '<div class="ff-nav__actions">' +
        '<a class="nav-sbi label' + (active === 'search' ? ' is-active' : '') + '" href="search.html" aria-label="Search by image">' + CAMERA + '<span>Search by image</span></a>' +
        '<span data-ff-account></span>' +
      '</div>';

    me().then(function (u) {
      var slot = nav.querySelector('[data-ff-account]');
      if (!u) {
        slot.outerHTML = '<a class="btn btn--ghost btn--sm" href="login.html">Sign in</a>';
        return;
      }
      slot.outerHTML =
        '<button class="icon-btn" type="button" aria-label="Notifications" data-ff-bell>' + BELL + (u.unread ? '<i class="dot"></i>' : '') + '</button>' +
        '<a class="ff-avatar" href="account.html" aria-label="My account (' + esc(u.username) + ')">' + avatar(u, 40) + '</a>';
      nav.querySelector('[data-ff-bell]').addEventListener('click', function () { askPermission(); checkAlerts(true); });
    });
  }

  function avatar(u, size) {
    if (u && u.avatar) return '<img src="' + esc(u.avatar) + '" alt="" width="' + size + '" height="' + size + '" style="object-fit:cover">';
    var letter = esc(((u && u.username) || '?').charAt(0).toUpperCase());
    return '<span class="avatar-letter" style="font-size:' + Math.round(size * 0.42) + 'px">' + letter + '</span>';
  }

  function initFooter() {
    var f = document.querySelector('[data-ff-footer]');
    if (!f) return;
    f.classList.add('ff-footer');
    f.innerHTML =
      '<img class="ff-footer__mark" src="assets/brand/ff-monogram-white.svg" alt="Fashion Find">' +
      '<img class="ff-footer__tag" src="assets/brand/ff-tagline-white.svg" alt="SEE IT. FIND IT. WEAR IT.">' +
      '<nav class="ff-footer__links label">' +
        '<a href="search.html">Search by image</a><a href="shop.html">Shop</a><a href="designers.html">Designers</a>' +
        '<a href="sell.html">Sell</a><a href="wanted.html">Wanted</a><a href="charte.html">Brand guidelines</a>' +
      '</nav>' +
      '<small>© 2026 FASHION FIND</small>';
  }

  /* ---------- Loader ---------- */
  function initLoader() {
    var el = document.querySelector('.ff-loader');
    if (!el) { document.body.classList.add('is-ready'); return; }
    var start = Date.now(), fired = false;
    function done() {
      if (fired) return;
      fired = true;
      setTimeout(function () { el.classList.add('is-done'); document.body.classList.add('is-ready'); }, Math.max(0, 1100 - (Date.now() - start)));
    }
    if (document.readyState === 'complete') done();
    else { window.addEventListener('load', done); setTimeout(done, 4000); }
  }

  /* ---------- Notifications ---------- */
  function stack() {
    var s = document.querySelector('.ff-toasts');
    if (!s) {
      s = document.createElement('div');
      s.className = 'ff-toasts';
      s.setAttribute('role', 'status');
      s.setAttribute('aria-live', 'polite');
      document.body.appendChild(s);
    }
    return s;
  }
  function toast(title, body, href) {
    var t = document.createElement(href ? 'a' : 'div');
    t.className = 'ff-toast';
    if (href) t.href = href;
    t.innerHTML = '<span class="ff-toast__mark">' + window.FFLogo.emblem() + '</span>' +
      '<div><div class="ff-toast__title"></div><div class="ff-toast__body"></div></div>' +
      '<button class="ff-toast__close" type="button" aria-label="Close">&times;</button>';
    t.querySelector('.ff-toast__title').textContent = title;
    t.querySelector('.ff-toast__body').textContent = body;
    function close() { t.classList.add('is-out'); setTimeout(function () { t.remove(); }, 300); }
    t.querySelector('button').addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); close(); });
    stack().prepend(t);
    setTimeout(close, 7000);
  }
  function system(title, body, href) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    try {
      var n = new Notification(title, { body: body, icon: ICON, badge: BADGE, tag: 'ff-' + Date.now() });
      if (href) n.onclick = function () { window.focus(); location.href = href; };
    } catch (e) { /* mobile browsers need a service worker */ }
  }
  function askPermission() { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); }
  function notify(title, body, href) { toast(title, body, href); system(title, body, href); }

  // WANTED matches and purchase confirmations, created server-side.
  function checkAlerts(manual) {
    me().then(function (u) {
      if (!u) return;
      api('/api/notifications').then(function (list) {
        if (!list.length) { if (manual) toast('Fashion Find', 'No new notifications. Your WANTED alerts stay active.', 'wanted.html'); return; }
        list.slice(0, 3).forEach(function (n) { notify(n.title, n.body, n.href); });
        api('/api/notifications/seen', { method: 'POST', body: { ids: list.map(function (n) { return n.id; }) } });
        var dot = document.querySelector('[data-ff-bell] .dot');
        if (dot) dot.remove();
      }).catch(function () {});
    });
  }

  window.FF = { api: api, me: me, requireMe: requireMe, esc: esc, avatar: avatar, notify: notify, toast: toast, askPermission: askPermission };

  function init() { initNav(); initFooter(); initLoader(); checkAlerts(false); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
