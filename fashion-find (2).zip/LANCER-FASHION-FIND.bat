@echo off
title Fashion Find
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installe.
  echo  Installez la version LTS depuis https://nodejs.org puis relancez ce fichier.
  start "" https://nodejs.org
  pause
  exit /b
)
if not exist "node_modules\@netlify\blobs" (
  echo.
  echo  Premiere ouverture : installation, merci de patienter...
  call npm install --no-audit --no-fund
)
echo.
echo  FASHION FIND est lance sur http://localhost:8090
echo  Laissez cette fenetre ouverte. Fermez-la pour arreter le site.
echo.
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8090"
node server\index.mjs
echo.
echo  Le serveur s'est arrete.
pause