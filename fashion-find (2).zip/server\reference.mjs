// FASHION FIND — reference data (brands, categories, sizes, conditions, colors).
// These are not listings: only the lists offered in the sell form and the search filters.

export const CATEGORIES = [
  { slug: 'hoodies-sweatshirts', name: 'Hoodies & Sweatshirts', sizes: 'clothing' },
  { slug: 't-shirts', name: 'T-Shirts', sizes: 'clothing' },
  { slug: 'jackets', name: 'Jackets', sizes: 'clothing' },
  { slug: 'leather-jackets', name: 'Leather Jackets', sizes: 'clothing' },
  { slug: 'jeans', name: 'Jeans', sizes: 'jeans' },
  { slug: 'baggy-pants', name: 'Baggy Pants', sizes: 'pants' },
  { slug: 'cargo-pants', name: 'Cargo Pants', sizes: 'pants' },
  { slug: 'trousers', name: 'Trousers', sizes: 'pants' },
  { slug: 'shorts', name: 'Shorts', sizes: 'pants' },
  { slug: 'shoes-sneakers', name: 'Shoes & Sneakers', sizes: 'shoes' },
  { slug: 'boots', name: 'Boots', sizes: 'shoes' },
  { slug: 'bags', name: 'Bags', sizes: 'one' },
  { slug: 'accessories', name: 'Accessories', sizes: 'one' },
  { slug: 'jewelry', name: 'Jewelry', sizes: 'jewelry' },
  { slug: 'belts', name: 'Belts', sizes: 'belts' },
  { slug: 'sunglasses', name: 'Sunglasses', sizes: 'one' },
];

// Size suggestions (sellers can type any other value).
export const SIZES = {
  clothing: ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'IT 44', 'IT 46', 'IT 48', 'IT 50', 'IT 52', 'IT 54', 'IT 56', '0', '1', '2', '3', '4', '5'],
  pants: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'IT 44', 'IT 46', 'IT 48', 'IT 50', 'IT 52', 'IT 54', 'W28', 'W30', 'W32', 'W34', 'W36'],
  jeans: ['W24', 'W25', 'W26', 'W27', 'W28', 'W29', 'W30', 'W31', 'W32', 'W33', 'W34', 'W36', 'W38', 'W40'],
  shoes: ['EU 36', 'EU 37', 'EU 38', 'EU 39', 'EU 40', 'EU 40.5', 'EU 41', 'EU 41.5', 'EU 42', 'EU 42.5', 'EU 43', 'EU 43.5', 'EU 44', 'EU 44.5', 'EU 45', 'EU 46', 'EU 47', 'EU 48'],
  jewelry: ['One size', 'Ring 48', 'Ring 50', 'Ring 52', 'Ring 54', 'Ring 56', 'Ring 58', 'Ring 60', 'Ring 62', 'Ring 64'],
  belts: ['One size', '75 cm', '80 cm', '85 cm', '90 cm', '95 cm', '100 cm', '105 cm', '110 cm'],
  one: ['One size'],
};

export const CONDITIONS = [
  { slug: 'new-tags', name: 'New with tags' },
  { slug: 'new', name: 'New without tags' },
  { slug: 'excellent', name: 'Excellent' },
  { slug: 'good', name: 'Good' },
  { slug: 'fair', name: 'Fair' },
];

export const COLORS = {
  black: { name: 'Black', hex: '#141414' },
  charcoal: { name: 'Charcoal', hex: '#3a3a3c' },
  grey: { name: 'Grey', hex: '#8c8c8c' },
  white: { name: 'White', hex: '#f3f2ee' },
  ecru: { name: 'Ecru', hex: '#e9e1cf' },
  beige: { name: 'Beige', hex: '#cdb995' },
  brown: { name: 'Brown', hex: '#6b4a32' },
  khaki: { name: 'Khaki', hex: '#6f6b45' },
  olive: { name: 'Olive', hex: '#4f5b2e' },
  'denim-blue': { name: 'Denim blue', hex: '#3f5f86' },
  'washed-blue': { name: 'Washed blue', hex: '#91abc6' },
  navy: { name: 'Navy', hex: '#1d2742' },
  blue: { name: 'Blue', hex: '#2457c5' },
  red: { name: 'Red', hex: '#b3261e' },
  burgundy: { name: 'Burgundy', hex: '#651a24' },
  pink: { name: 'Pink', hex: '#e7a2b4' },
  orange: { name: 'Orange', hex: '#df7a2a' },
  yellow: { name: 'Yellow', hex: '#ecc53a' },
  green: { name: 'Green', hex: '#2f7a4a' },
  purple: { name: 'Purple', hex: '#6a4c93' },
  silver: { name: 'Silver', hex: '#c3c7cc' },
  gold: { name: 'Gold', hex: '#c9a44c' },
  multicolor: { name: 'Multicolor', hex: '#9b59b6' },
};

export const GROUPS = [
  { slug: 'designer', name: 'Designer / Luxury' },
  { slug: 'underground', name: 'Underground / Streetwear' },
  { slug: 'footwear', name: 'Sneakers / Footwear' },
];

// [slug, name, origin, group]
export const BRANDS = [
  // Designer / Luxury
  ['balenciaga', 'Balenciaga', 'Paris', 'designer'],
  ['rick-owens', 'Rick Owens', 'Paris', 'designer'],
  ['rick-owens-drkshdw', 'Rick Owens DRKSHDW', 'Paris', 'designer'],
  ['chrome-hearts', 'Chrome Hearts', 'Los Angeles', 'designer'],
  ['maison-margiela', 'Maison Margiela', 'Paris', 'designer'],
  ['raf-simons', 'Raf Simons', 'Antwerp', 'designer'],
  ['vetements', 'Vetements', 'Paris · Zurich', 'designer'],
  ['prada', 'Prada', 'Milan', 'designer'],
  ['dior-homme', 'Dior Homme', 'Paris', 'designer'],
  ['dior', 'Dior', 'Paris', 'designer'],
  ['saint-laurent', 'Saint Laurent', 'Paris', 'designer'],
  ['gucci', 'Gucci', 'Florence', 'designer'],
  ['givenchy', 'Givenchy', 'Paris', 'designer'],
  ['acne-studios', 'Acne Studios', 'Stockholm', 'designer'],
  ['comme-des-garcons', 'Comme des Garçons', 'Tokyo', 'designer'],
  ['yohji-yamamoto', 'Yohji Yamamoto', 'Tokyo', 'designer'],
  ['jean-paul-gaultier', 'Jean Paul Gaultier', 'Paris', 'designer'],
  ['helmut-lang', 'Helmut Lang', 'Vienna · New York', 'designer'],
  ['ann-demeulemeester', 'Ann Demeulemeester', 'Antwerp', 'designer'],
  ['julius', 'Julius', 'Tokyo', 'designer'],
  ['alexander-mcqueen', 'Alexander McQueen', 'London', 'designer'],
  ['issey-miyake', 'Issey Miyake', 'Tokyo', 'designer'],
  ['bottega-veneta', 'Bottega Veneta', 'Milan', 'designer'],
  ['celine', 'Celine', 'Paris', 'designer'],
  ['loewe', 'Loewe', 'Madrid', 'designer'],
  ['louis-vuitton', 'Louis Vuitton', 'Paris', 'designer'],
  ['junya-watanabe', 'Junya Watanabe', 'Tokyo', 'designer'],
  ['carol-christian-poell', 'Carol Christian Poell', 'Milan', 'designer'],
  ['boris-bidjan-saberi', 'Boris Bidjan Saberi', 'Barcelona', 'designer'],
  ['vivienne-westwood', 'Vivienne Westwood', 'London', 'designer'],
  ['heliot-emil', 'Heliot Emil', 'Copenhagen', 'designer'],
  ['amiri', 'Amiri', 'Los Angeles', 'designer'],
  ['moncler', 'Moncler', 'Milan', 'designer'],
  // Underground / Streetwear
  ['enfants-riches-deprimes', 'Enfants Riches Déprimés', 'Los Angeles', 'underground'],
  ['alyx', '1017 ALYX 9SM', 'Ferrara', 'underground'],
  ['number-nine', 'Number (N)ine', 'Tokyo', 'underground'],
  ['undercover', 'Undercover', 'Tokyo', 'underground'],
  ['hysteric-glamour', 'Hysteric Glamour', 'Tokyo', 'underground'],
  ['cav-empt', 'Cav Empt', 'Tokyo', 'underground'],
  ['gallery-dept', 'Gallery Dept.', 'Los Angeles', 'underground'],
  ['who-decides-war', 'Who Decides War', 'New York', 'underground'],
  ['our-legacy', 'Our Legacy', 'Stockholm', 'underground'],
  ['represent', 'Represent', 'Manchester', 'underground'],
  ['jaded-london', 'Jaded London', 'London', 'underground'],
  ['affliction', 'Affliction', 'Los Angeles', 'underground'],
  ['ed-hardy', 'Ed Hardy', 'Los Angeles', 'underground'],
  ['diesel', 'Diesel', 'Breganze', 'underground'],
  ['supreme', 'Supreme', 'New York', 'underground'],
  ['bape', 'BAPE', 'Tokyo', 'underground'],
  ['stussy', 'Stüssy', 'California', 'underground'],
  ['palace', 'Palace', 'London', 'underground'],
  ['corteiz', 'Corteiz', 'London', 'underground'],
  ['denim-tears', 'Denim Tears', '', 'underground'],
  ['evisu', 'Evisu', 'Osaka', 'underground'],
  ['r13', 'R13', 'New York', 'underground'],
  ['off-white', 'Off-White', 'Milan', 'underground'],
  ['kapital', 'Kapital', 'Okayama', 'underground'],
  ['visvim', 'visvim', 'Tokyo', 'underground'],
  ['stone-island', 'Stone Island', 'Ravarino', 'underground'],
  ['cp-company', 'C.P. Company', 'Bologna', 'underground'],
  ['fear-of-god', 'Fear of God', 'Los Angeles', 'underground'],
  ['kiko-kostadinov', 'Kiko Kostadinov', 'London', 'underground'],
  ['martine-rose', 'Martine Rose', 'London', 'underground'],
  // Sneakers / Footwear
  ['nike', 'Nike', 'Beaverton', 'footwear'],
  ['adidas', 'Adidas', 'Herzogenaurach', 'footwear'],
  ['new-balance', 'New Balance', 'Boston', 'footwear'],
  ['salomon', 'Salomon', 'Annecy', 'footwear'],
  ['roa', 'ROA', 'Milan', 'footwear'],
  ['guidi', 'Guidi', 'Pisa', 'footwear'],
  ['asics', 'Asics', 'Kobe', 'footwear'],
  ['converse', 'Converse', 'Boston', 'footwear'],
];

export function slugify(name) {
  return String(name || '')
    .toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}
