/* FASHION FIND — logo inline. Fichier généré par tools/build-brand.mjs : ne pas modifier à la main. */
(function () {
  var T = {"emblem":"<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"#000000\"/><circle class=\"ff-ring\" cx=\"60\" cy=\"60\" r=\"53\" fill=\"none\" stroke=\"#075BFF\" stroke-width=\"3\" pathLength=\"1\"/><g><g class=\"ff-letters\" fill=\"#FFFFFF\"><path d=\"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z\"/><path d=\"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z\"/></g><g class=\"ff-outline\" fill=\"none\" stroke=\"#075BFF\" stroke-width=\"2.2\" stroke-linejoin=\"miter\"><path d=\"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z\" pathLength=\"1\"/><path d=\"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z\" pathLength=\"1\"/></g></g>","emblemBare":"<circle class=\"ff-ring\" cx=\"60\" cy=\"60\" r=\"53\" fill=\"none\" stroke=\"#075BFF\" stroke-width=\"3\" pathLength=\"1\"/><g><g class=\"ff-letters\" fill=\"#FFFFFF\"><path d=\"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z\"/><path d=\"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z\"/></g><g class=\"ff-outline\" fill=\"none\" stroke=\"#075BFF\" stroke-width=\"2.2\" stroke-linejoin=\"miter\"><path d=\"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z\" pathLength=\"1\"/><path d=\"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z\" pathLength=\"1\"/></g></g>","mono":"<g class=\"ff-letters\" fill=\"%C%\"><path d=\"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z\"/><path d=\"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z\"/></g>","word":"<defs><clipPath id=\"%ID%-c\"><rect x=\"-2.95\" y=\"-0.95\" width=\"232.1\" height=\"21.9\"/></clipPath></defs><g clip-path=\"url(#%ID%-c)\" fill=\"none\" stroke=\"%C%\" stroke-width=\"1.9\" stroke-linejoin=\"miter\" stroke-miterlimit=\"6\"><path transform=\"translate(0 0)\" d=\"M11,0 H0 V20 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(18.5 0)\" d=\"M0,20 L8,0 L16,20\" stroke-linecap=\"square\"/><path transform=\"translate(18.5 0)\" d=\"M2.8,13 H13.2\" stroke-linecap=\"butt\"/><path transform=\"translate(41.6 0)\" d=\"M12.6,3.6 C11.5,1.3 9.4,0 6.6,0 C3.3,0 0.9,1.9 0.9,5 C0.9,8.3 3.7,9.2 6.8,9.8 C10.3,10.5 13.2,11.6 13.2,15.1 C13.2,18.2 10.6,20 6.7,20 C3.6,20 1.1,18.7 0,16.3\" stroke-linecap=\"butt\"/><path transform=\"translate(63.4 0)\" d=\"M0,0 V20 M14,0 V20 M0,10 H14\" stroke-linecap=\"square\"/><path transform=\"translate(86.4 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(95 0)\" d=\"M20,10 A10,10 0 1 1 0,10 A10,10 0 1 1 20,10 Z\" stroke-linecap=\"butt\"/><path transform=\"translate(123.6 0)\" d=\"M0,20 V0 L14,20 V0\" stroke-linecap=\"square\"/><path transform=\"translate(159.6 0)\" d=\"M11,0 H0 V20 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(179.6 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(188.6 0)\" d=\"M0,20 V0 L14,20 V0\" stroke-linecap=\"square\"/><path transform=\"translate(211.6 0)\" d=\"M0,0 H4.6 A10,10 0 0 1 4.6,20 H0 Z\" stroke-linecap=\"butt\"/></g>","tag":"<defs><clipPath id=\"%ID%-c\"><rect x=\"-3.4\" y=\"-1.4\" width=\"442.9\" height=\"22.8\"/></clipPath></defs><g clip-path=\"url(#%ID%-c)\" fill=\"none\" stroke=\"%C%\" stroke-width=\"2.8\" stroke-linejoin=\"miter\" stroke-miterlimit=\"6\"><path transform=\"translate(0 0)\" d=\"M12.6,3.6 C11.5,1.3 9.4,0 6.6,0 C3.3,0 0.9,1.9 0.9,5 C0.9,8.3 3.7,9.2 6.8,9.8 C10.3,10.5 13.2,11.6 13.2,15.1 C13.2,18.2 10.6,20 6.7,20 C3.6,20 1.1,18.7 0,16.3\" stroke-linecap=\"butt\"/><path transform=\"translate(24.8 0)\" d=\"M11,0 H0 V20 H11 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(47.8 0)\" d=\"M11,0 H0 V20 H11 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(82.8 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(93.8 0)\" d=\"M0,0 H14 M7,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(112.2 0)\" d=\"M0,20 h0.01\" stroke-linecap=\"square\"/><path transform=\"translate(136.2 0)\" d=\"M11,0 H0 V20 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(159.2 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(171.2 0)\" d=\"M0,20 V0 L14,20 V0\" stroke-linecap=\"square\"/><path transform=\"translate(197.2 0)\" d=\"M0,0 H4.6 A10,10 0 0 1 4.6,20 H0 Z\" stroke-linecap=\"butt\"/><path transform=\"translate(235.8 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(246.8 0)\" d=\"M0,0 H14 M7,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(265.2 0)\" d=\"M0,20 h0.01\" stroke-linecap=\"square\"/><path transform=\"translate(289.2 0)\" d=\"M0,0 L5.5,20 L11,0 L16.5,20 L22,0\" stroke-linecap=\"square\"/><path transform=\"translate(321.7 0)\" d=\"M11,0 H0 V20 H11 M0,9.6 H9.4\" stroke-linecap=\"square\"/><path transform=\"translate(343.2 0)\" d=\"M0,20 L8,0 L16,20\" stroke-linecap=\"square\"/><path transform=\"translate(343.2 0)\" d=\"M2.8,13 H13.2\" stroke-linecap=\"butt\"/><path transform=\"translate(369.7 0)\" d=\"M0,20 V0 H7.2 A5,5 0 0 1 7.2,10 H0\" stroke-linecap=\"square\"/><path transform=\"translate(369.7 0)\" d=\"M6.6,10 L13,20\" stroke-linecap=\"square\"/><path transform=\"translate(406.7 0)\" d=\"M0,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(417.7 0)\" d=\"M0,0 H14 M7,0 V20\" stroke-linecap=\"square\"/><path transform=\"translate(436.1 0)\" d=\"M0,20 h0.01\" stroke-linecap=\"square\"/></g>"};
  var M = {"crop":{"x":32,"y":24,"w":56,"h":72},"word":{"w":226.2,"h":0.95},"tag":{"w":436.0999999999999,"h":1.4},"left":"M32,24 L69,24 L69,37 L46,37 L46,45 L65,45 L65,58 L46,58 L46,80 L32,80 Z","right":"M88,96 L51,96 L51,83 L74,83 L74,75 L55,75 L55,62 L74,62 L74,40 L88,40 Z","blue":"#075BFF"};
  var n = 0;
  function uid() { n += 1; return 'ff' + n + Math.random().toString(36).slice(2, 6); }
  function sub(s, c) { return s.split('%ID%').join(uid()).split('%C%').join(c || 'currentColor'); }
  function wrap(vb, body, label, cls) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '" class="' + (cls || '') + '" role="img" aria-label="' + label + '" focusable="false">' + body + '</svg>';
  }
  var api = {
    meta: M,
    emblem: function (cls) { return wrap('0 0 120 120', sub(T.emblem), 'Fashion Find', cls); },
    emblemBare: function (cls) { return wrap('0 0 120 120', sub(T.emblemBare), 'Fashion Find', cls); },
    mono: function (color, cls) {
      var c = M.crop;
      return wrap((c.x - 2) + ' ' + (c.y - 2) + ' ' + (c.w + 4) + ' ' + (c.h + 4), sub(T.mono, color), 'Fashion Find', cls);
    },
    wordmark: function (color, cls) {
      var h = M.word.h;
      return wrap((-h) + ' ' + (-h) + ' ' + (M.word.w + 2 * h) + ' ' + (20 + 2 * h), sub(T.word, color), 'FASHION FIND', cls);
    },
    tagline: function (color, cls) {
      var h = M.tag.h;
      return wrap((-h) + ' ' + (-h) + ' ' + (M.tag.w + 2 * h) + ' ' + (20 + 2 * h), sub(T.tag, color), 'SEE IT. FIND IT. WEAR IT.', cls);
    },
    /* <span data-ff-logo="emblem|emblem-bare|mono|wordmark|tagline" data-color="#075BFF"></span> */
    mount: function (root) {
      (root || document).querySelectorAll('[data-ff-logo]').forEach(function (el) {
        var kind = el.getAttribute('data-ff-logo');
        var color = el.getAttribute('data-color');
        var html = kind === 'emblem' ? api.emblem()
          : kind === 'emblem-bare' ? api.emblemBare()
          : kind === 'mono' ? api.mono(color)
          : kind === 'wordmark' ? api.wordmark(color)
          : kind === 'tagline' ? api.tagline(color) : '';
        el.innerHTML = html;
        el.removeAttribute('data-ff-logo');
        el.classList.add('ff-logo', 'ff-logo--' + kind);
      });
    },
  };
  window.FFLogo = api;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { api.mount(); });
  else api.mount();
})();
