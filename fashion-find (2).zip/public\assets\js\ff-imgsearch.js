/* FASHION FIND — image preparation in the browser (search by image, listing photos, avatars).
   Images are re-encoded through a canvas: this also strips EXIF metadata such as GPS location. */
(function () {
  var KEY = 'ff-sbi-pending';

  function readFile(file) {
    return new Promise(function (ok, ko) {
      if (!file || !/^image\//.test(file.type)) { ko(new Error('Please choose an image file (screenshot or photo).')); return; }
      if (file.size > 30 * 1024 * 1024) { ko(new Error('Image too large (30 MB max).')); return; }
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () { ok(img); };
      img.onerror = function () { URL.revokeObjectURL(url); ko(new Error('This image cannot be read. Try a JPEG or PNG (HEIC photos: export as JPEG first).')); };
      img.src = url;
    });
  }

  function draw(img, maxEdge) {
    var s = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
    var c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * s));
    c.height = Math.max(1, Math.round(img.naturalHeight * s));
    var x = c.getContext('2d');
    x.fillStyle = '#fff';
    x.fillRect(0, 0, c.width, c.height);
    x.imageSmoothingQuality = 'high';
    x.drawImage(img, 0, 0, c.width, c.height);
    return c;
  }

  /* Dominant colors measured from the pixels (weighted toward the centre). */
  function dominantColors(img, palette) {
    if (!palette) return [];
    var c = draw(img, 72);
    var px = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    var keys = Object.keys(palette).filter(function (k) { return k !== 'multicolor'; });
    var rgb = keys.map(function (k) { var n = parseInt(palette[k].hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; });
    var score = {}, total = 0;
    for (var y = 0; y < c.height; y++) {
      for (var xx = 0; xx < c.width; xx++) {
        var i = (y * c.width + xx) * 4;
        var dx = (xx / c.width - 0.5) * 2, dy = (y / c.height - 0.5) * 2;
        var w = Math.exp(-(dx * dx + dy * dy) * 1.6);
        var best = 0, bd = 1e9;
        for (var k = 0; k < rgb.length; k++) {
          var r = px[i] - rgb[k][0], g = px[i + 1] - rgb[k][1], b = px[i + 2] - rgb[k][2];
          var d = 2 * r * r + 4 * g * g + 3 * b * b;
          if (d < bd) { bd = d; best = k; }
        }
        score[keys[best]] = (score[keys[best]] || 0) + w;
        total += w;
      }
    }
    return Object.keys(score).map(function (k) { return [k, score[k] / total]; })
      .filter(function (e) { return e[1] > 0.12; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 3)
      .map(function (e) { return e[0]; });
  }

  /* Screenshot for search by image */
  function prepare(file, palette) {
    return readFile(file).then(function (img) {
      var out = {
        dataUrl: draw(img, 1568).toDataURL('image/jpeg', 0.88),
        thumb: draw(img, 240).toDataURL('image/jpeg', 0.72),
        localColors: dominantColors(img, palette),
      };
      URL.revokeObjectURL(img.src);
      return out;
    });
  }

  /* Real photo of an item for a listing: large version for zoom + grid thumbnail */
  function preparePhoto(file, opts) {
    opts = opts || {};
    var minEdge = opts.minEdge == null ? 600 : opts.minEdge;
    return readFile(file).then(function (img) {
      if (Math.max(img.naturalWidth, img.naturalHeight) < minEdge) {
        URL.revokeObjectURL(img.src);
        throw new Error('“' + file.name + '” is too small (' + img.naturalWidth + '×' + img.naturalHeight + '). Use a photo of at least ' + minEdge + ' px for sharp detail.');
      }
      var full = draw(img, opts.maxEdge || 2400);
      var thumb = draw(img, opts.thumbEdge || 760);
      URL.revokeObjectURL(img.src);
      return { full: full.toDataURL('image/jpeg', 0.9), thumb: thumb.toDataURL('image/jpeg', 0.82), width: full.width, height: full.height };
    });
  }

  /* Home → search page: the chosen screenshot is passed along without re-uploading */
  function stash(file) {
    return prepare(file, null).then(function (p) {
      try { sessionStorage.setItem(KEY, JSON.stringify({ dataUrl: p.dataUrl, thumb: p.thumb })); }
      catch (e) { throw new Error('Image too large to pass along. Upload it from the Search by image page.'); }
    });
  }
  function take() {
    try { var v = sessionStorage.getItem(KEY); sessionStorage.removeItem(KEY); return v ? JSON.parse(v) : null; }
    catch (e) { return null; }
  }
  function colorsFromDataUrl(dataUrl, palette) {
    return new Promise(function (ok) {
      var img = new Image();
      img.onload = function () { ok(dominantColors(img, palette)); };
      img.onerror = function () { ok([]); };
      img.src = dataUrl;
    });
  }

  window.FFImageSearch = { prepare: prepare, preparePhoto: preparePhoto, stash: stash, take: take, colorsFromDataUrl: colorsFromDataUrl };
})();
