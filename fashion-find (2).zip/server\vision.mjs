// FASHION FIND — screenshot analysis with Claude (vision + structured JSON output).
// Configuration: see docs/AI-SETUP.md (ANTHROPIC_API_KEY, optional FF_VISION_MODEL).
import Anthropic from '@anthropic-ai/sdk';

export const MODEL = process.env.FF_VISION_MODEL || 'claude-opus-5-5';

let client = null;
function getClient() {
  if (!client) client = new Anthropic(); // ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN or an `ant auth login` profile
  return client;
}

export class VisionUnavailable extends Error {}

function schema(ref) {
  const str = { type: 'string' };
  const strList = { type: 'array', items: str };
  return {
    type: 'object',
    additionalProperties: false,
    required: ['is_fashion', 'summary', 'items'],
    properties: {
      is_fashion: { type: 'boolean' },
      summary: str,
      items: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          required: ['category', 'label', 'brand', 'brand_other', 'brand_confidence', 'brand_evidence', 'model', 'colors', 'fit', 'materials', 'details', 'patterns', 'logos_text', 'keywords'],
          properties: {
            category: { type: 'string', enum: ref.categories.map((c) => c.slug) },
            label: str,
            brand: { type: 'string', enum: [...ref.brands.map((b) => b.slug), 'unknown'] },
            brand_other: str,
            brand_confidence: { type: 'number' },
            brand_evidence: str,
            model: str,
            colors: { type: 'array', items: { type: 'string', enum: Object.keys(ref.colors) } },
            fit: str,
            materials: strList,
            details: strList,
            patterns: strList,
            logos_text: strList,
            keywords: strList,
          },
        },
      },
    },
  };
}

function systemPrompt(ref) {
  const brands = ref.brands.map((b) => `${b.slug} = ${b.name}`).join('\n');
  return `You are the visual recognition engine of Fashion Find, a resale marketplace for designer, luxury, archive, streetwear and underground fashion.
You receive a screenshot (Instagram post, street photo, product page, film still…). Identify each clearly visible garment or accessory and describe it so the platform can find the exact listing or similar items.

Rules:
- One entry per clearly visible piece, the most prominent first (5 at most). Ignore app interface elements and the background.
- brand: a slug from the list below only when a visual cue supports it (readable logo, signature design, iconic cut or detail). Otherwise "unknown". If you recognise a brand that is not in the list, put its name in brand_other.
- brand_confidence between 0 and 1, calibrated: 0.9+ only when a logo or an iconic model is clearly visible. brand_evidence explains the cue in one sentence.
- model: the model name only if you recognise it with confidence (e.g. "Geobasket", "Tabi boots"), otherwise an empty string. Never invent one.
- colors: enum values only, dominant color first.
- label, fit, materials, details, patterns, keywords: in English, lowercase, using words a seller would put in a listing title or description (e.g. "oversized", "washed", "leather", "chunky sole", "cross").
- logos_text: text or logos readable on the piece, verbatim.
- summary: one or two sentences in English describing what you see.
- If the image contains no clothing, is_fashion = false and items = [].

Brands known to the platform:
${brands}`;
}

/**
 * @param {object} ref   { categories, brands, colors }
 * @param {{ mediaType: string, data: string }} image  base64 without prefix
 */
export async function analyzeImage(ref, image) {
  let c;
  try { c = getClient(); } catch (e) { throw new VisionUnavailable(e.message); }
  let response;
  try {
    response = await c.beta.messages.create({
      model: MODEL,
      max_tokens: 8000,
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default',
      output_config: { effort: 'low', format: { type: 'json_schema', schema: schema(ref) } },
      system: [{ type: 'text', text: systemPrompt(ref), cache_control: { type: 'ephemeral' } }],
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: image.mediaType, data: image.data } },
          { type: 'text', text: 'Analyze the clothing in this screenshot for a Fashion Find search.' },
        ],
      }],
    });
  } catch (e) {
    if (e instanceof Anthropic.AuthenticationError || e instanceof Anthropic.PermissionDeniedError) {
      throw new VisionUnavailable('Invalid or missing Anthropic credentials.');
    }
    if (e instanceof Anthropic.RateLimitError) throw new Error('Too many searches at once, please try again in a moment.');
    if (e instanceof Anthropic.APIConnectionError) throw new VisionUnavailable('The image recognition service cannot be reached.');
    if (e instanceof Anthropic.APIError) throw new Error(`Image analysis failed (${e.status ?? 'API error'}).`);
    // No credentials at all: the SDK throws before sending the request.
    throw new VisionUnavailable(e.message);
  }

  if (response.stop_reason === 'refusal') throw new Error('This image could not be analyzed.');
  if (response.stop_reason === 'max_tokens') throw new Error('Analysis was cut short, try a simpler screenshot.');
  const text = response.content.find((b) => b.type === 'text')?.text;
  if (!text) throw new Error('Empty analysis response.');
  return { ...JSON.parse(text), model: response.model };
}
