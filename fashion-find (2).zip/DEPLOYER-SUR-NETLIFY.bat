@echo off
title Fashion Find - mise en ligne Netlify
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js n'est pas installe. Installez la version LTS depuis https://nodejs.org puis relancez ce fichier.
  start "" https://nodejs.org
  pause
  exit /b
)
if not exist "node_modules\@netlify\blobs" (
  echo.
  echo  Installation des dependances du site...
  call npm install --no-audit --no-fund
)
where netlify >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Installation de l'outil Netlify (une seule fois)...
  call npm install -g netlify-cli
)
echo.
echo  1/2  Connexion a votre compte Netlify (une page va s'ouvrir dans le navigateur)...
call netlify login
echo.
echo  2/2  Mise en ligne de FASHION FIND...
echo  La premiere fois, choisissez "Create and configure a new project", votre equipe, puis un nom de site.
echo.
call netlify deploy --prod
echo.
echo  Termine. L'adresse de votre site est indiquee ci-dessus (Production URL / Deployed to production URL).
pause