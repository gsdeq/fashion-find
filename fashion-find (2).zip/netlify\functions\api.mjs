// FASHION FIND — the marketplace API as a Netlify Function.
// Same code as the local server (server/app.mjs); data and photos are stored in Netlify Blobs.
import { handle } from '../../server/app.mjs';
import { netlifyStorage } from '../../server/storage.mjs';

let storage;

export default async (req, context) => {
  storage ||= netlifyStorage();
  return handle(req, {
    storage: await storage,
    ip: context.ip,
    secure: new URL(req.url).protocol === 'https:',
    waitUntil: context.waitUntil ? (p) => context.waitUntil(p) : null,
  });
};

export const config = {
  path: ['/api/*', '/uploads/*'],
};
