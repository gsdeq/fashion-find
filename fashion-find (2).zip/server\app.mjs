// FASHION FIND — marketplace API (accounts, listings, photos, search, profiles, favorites,
// reviews, search by image, WANTED, notifications).
// Platform-neutral: takes a web Request, returns a web Response. Used by
//   - server/index.mjs            (local Node server, `npm start`)
//   - netlify/functions/api.mjs   (Netlify Functions)
import { randomUUID, randomBytes } from 'node:crypto';
import { BRANDS, CATEGORIES, CONDITIONS, COLORS, SIZES, slugify } from './reference.mjs';
import { hashPassword, verifyPassword, sha, newToken, readCookie, sessionCookie, rateLimit, SESSION_DAYS } from './auth.mjs';
import { rank } from './search.mjs';
import { analyzeImage, VisionUnavailable, MODEL } from './vision.mjs';

const CATEGORY_NAME = Object.fromEntries(CATEGORIES.map((c) => [c.slug, c.name]));
const COND_NAME = Object.fromEntries(CONDITIONS.map((c) => [c.slug, c.name]));
const REF_BRANDS = BRANDS.map(([slug, name, origin, group]) => ({ slug, name, origin, group, user_added: 0 }));
const now = () => new Date().toISOString();

class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const fail = (status, message) => { throw new HttpError(status, message); };

const json = (status, body, headers = {}) => status === 204
  ? new Response(null, { status: 204, headers })
  : new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers } });

async function readBody(req, max = 1024 * 1024) {
  const len = Number(req.headers.get('content-length') || 0);
  if (len > max) fail(413, 'Request too large.');
  const text = await req.text();
  if (text.length > max) fail(413, 'Request too large.');
  if (!text) return {};
  try { return JSON.parse(text); } catch { fail(400, 'Invalid JSON.'); }
}
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const bool = (v) => v === true || v === 1 || v === '1' || v === 'true';
export function normText(...parts) {
  return parts.flat().join(' ').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
}

/* ---------- Transactions on the data document ---------- */
async function transact(storage, fn, { retries = 6, optional = false } = {}) {
  for (let i = 0; i <= retries; i++) {
    const { doc, etag } = await storage.read();
    const draft = structuredClone(doc);
    const result = await fn(draft);
    const saved = await storage.write(draft, etag);
    if (saved.ok) return result;
    if (optional) return result;
    await new Promise((r) => setTimeout(r, 30 + Math.random() * 120 * (i + 1)));
  }
  fail(503, 'The server is busy, please try again.');
}

/* ---------- Views over the document ---------- */
function allBrands(doc) {
  const counts = {};
  for (const l of Object.values(doc.listings)) if (l.status === 'active') counts[l.brand] = (counts[l.brand] || 0) + 1;
  return [...REF_BRANDS, ...doc.brandsAdded.map((b) => ({ slug: b.slug, name: b.name, origin: b.origin || '', group: 'added', user_added: 1 }))]
    .map((b) => ({ ...b, count: counts[b.slug] || 0 }))
    .sort((a, b) => a.name.localeCompare(b.name, 'en', { sensitivity: 'base' }));
}
const brandName = (doc, slug) => REF_BRANDS.find((b) => b.slug === slug)?.name || doc.brandsAdded.find((b) => b.slug === slug)?.name || slug;
const photoUrl = (p, thumb) => `/uploads/${p.id}${thumb ? '_t' : ''}.${p.ext}`;
const avatarUrl = (doc, id) => (id && doc.photos[id] ? photoUrl(doc.photos[id], true) : null);

function card(doc, l) {
  const ph = l.photoIds.map((id) => doc.photos[id]).find(Boolean);
  const seller = doc.users[l.sellerId];
  return {
    id: l.id, title: l.title,
    brand: { slug: l.brand, name: brandName(doc, l.brand) },
    category: l.category, categoryName: CATEGORY_NAME[l.category] || l.category,
    size: l.size, condition: COND_NAME[l.condition] || l.condition, price: l.price,
    negotiable: !!l.negotiable, hasProof: !!l.hasProof, status: l.status,
    photo: ph ? { url: photoUrl(ph), thumb: photoUrl(ph, true), w: ph.width, h: ph.height } : null,
    seller: { username: seller?.username || 'deleted', avatar: avatarUrl(doc, seller?.avatarId) },
    favorites: l.favorites || 0, createdAt: l.createdAt,
  };
}

function sellerStats(doc, userId) {
  let active = 0, sold = 0;
  for (const l of Object.values(doc.listings)) {
    if (l.sellerId !== userId) continue;
    if (l.status === 'active') active += 1;
    if (l.status === 'sold') sold += 1;
  }
  const rs = Object.values(doc.reviews).filter((r) => r.sellerId === userId);
  const avg = rs.length ? rs.reduce((s, r) => s + r.rating, 0) / rs.length : null;
  return { active, sold, total: active + sold, rating: avg == null ? null : Math.round(avg * 10) / 10, reviews: rs.length };
}
const publicUser = (doc, u) => ({ username: u.username, bio: u.bio, city: u.city, avatar: avatarUrl(doc, u.avatarId), createdAt: u.createdAt, stats: sellerStats(doc, u.id) });
const userByName = (doc, name) => Object.values(doc.users).find((u) => u.username.toLowerCase() === String(name || '').toLowerCase());

function currentUser(doc, req) {
  const token = readCookie(req);
  if (!token) return null;
  const s = doc.sessions[sha(token)];
  if (!s || s.expiresAt < now()) return null;
  return doc.users[s.userId] || null;
}

function searchText(doc, l) {
  return normText(brandName(doc, l.brand), l.title, CATEGORY_NAME[l.category] || l.category, l.size, l.colors.map((c) => COLORS[c]?.name || c), l.description);
}

/* ---------- Listing validation ---------- */
function resolveBrand(doc, body, user) {
  const slug = str(body.brand, 60);
  if (slug && (REF_BRANDS.some((b) => b.slug === slug) || doc.brandsAdded.some((b) => b.slug === slug))) return slug;
  const name = str(body.brandName, 60);
  if (!name || name.length < 2) fail(400, 'Please enter the brand.');
  const s = slugify(name);
  if (!s) fail(400, 'Invalid brand name.');
  const existing = allBrands(doc).find((b) => b.slug === s || b.name.toLowerCase() === name.toLowerCase());
  if (existing) return existing.slug;
  doc.brandsAdded.push({ slug: s, name, origin: '', createdBy: user.id, createdAt: now() });
  return s;
}

function validateListing(doc, body, user, listingId = null) {
  const v = {
    title: str(body.title, 120), category: str(body.category, 30), size: str(body.size, 20), condition: str(body.condition, 30),
    price: Math.round(Number(body.price)), description: str(body.description, 4000),
    colors: Array.isArray(body.colors) ? [...new Set(body.colors.filter((c) => COLORS[c]))].slice(0, 4) : [],
    photoIds: Array.isArray(body.photoIds) ? body.photoIds.map((x) => str(x, 40)).slice(0, 12) : [],
    negotiable: bool(body.negotiable), hasProof: bool(body.hasProof),
  };
  if (v.title.length < 3) fail(400, 'The product name is too short.');
  if (!CATEGORY_NAME[v.category]) fail(400, 'Please choose a category.');
  if (!v.size) fail(400, 'Please enter the size.');
  if (!COND_NAME[v.condition]) fail(400, 'Please choose the condition.');
  if (!Number.isFinite(v.price) || v.price < 1 || v.price > 1000000) fail(400, 'Invalid price (between €1 and €1,000,000).');
  if (v.description.length < 20) fail(400, 'Describe the item in at least 20 characters.');
  if (!v.photoIds.length) fail(400, 'Add at least one real photo of the item.');
  if (!bool(body.certify)) fail(400, 'Please confirm the photos are yours and show the item for sale.');
  for (const id of v.photoIds) {
    const p = doc.photos[id];
    if (!p || p.ownerId !== user.id || (p.listingId && p.listingId !== listingId)) fail(400, 'Invalid photo.');
  }
  v.brand = resolveBrand(doc, body, user);
  return v;
}

function attachPhotos(doc, listingId, ids) {
  for (const p of Object.values(doc.photos)) if (p.listingId === listingId) p.listingId = null;
  ids.forEach((id, i) => { doc.photos[id].listingId = listingId; doc.photos[id].position = i; });
}

/* ---------- Search ---------- */
function searchListings(doc, q) {
  const terms = normText(q.q || '').split(' ').filter(Boolean).slice(0, 8);
  const seller = q.seller ? userByName(doc, q.seller) : null;
  let list = Object.values(doc.listings).filter((l) => {
    if (l.status !== 'active') return false;
    if (q.brand && l.brand !== q.brand) return false;
    if (q.category && l.category !== q.category) return false;
    if (q.size && l.size.toLowerCase() !== String(q.size).toLowerCase()) return false;
    if (q.condition && l.condition !== q.condition) return false;
    if (q.color && !l.colors.includes(q.color)) return false;
    if (q.seller && (!seller || l.sellerId !== seller.id)) return false;
    if (Number(q.min) > 0 && l.price < Number(q.min)) return false;
    if (Number(q.max) > 0 && l.price > Number(q.max)) return false;
    if (terms.length) { const t = searchText(doc, l); if (!terms.every((x) => t.includes(x))) return false; }
    return true;
  });
  const byDate = (a, b) => (a.createdAt < b.createdAt ? 1 : -1);
  const sorters = {
    'price-asc': (a, b) => a.price - b.price || byDate(a, b),
    'price-desc': (a, b) => b.price - a.price || byDate(a, b),
    popular: (a, b) => ((b.favorites || 0) * 3 + b.views) - ((a.favorites || 0) * 3 + a.views) || byDate(a, b),
  };
  list.sort(sorters[q.sort] || byDate);
  const pageSize = 36;
  const page = Math.max(1, Math.floor(Number(q.page)) || 1);
  return { total: list.length, page, pageSize, items: list.slice((page - 1) * pageSize, page * pageSize).map((l) => card(doc, l)) };
}

function facets(doc, q) {
  const list = Object.values(doc.listings).filter((l) => l.status === 'active' && (!q.brand || l.brand === q.brand));
  const cats = {}, sizes = {};
  let min = null, max = null;
  for (const l of list) {
    cats[l.category] = (cats[l.category] || 0) + 1;
    const k = l.size;
    const key = Object.keys(sizes).find((s) => s.toLowerCase() === k.toLowerCase()) || k;
    sizes[key] = (sizes[key] || 0) + 1;
    min = min == null ? l.price : Math.min(min, l.price);
    max = max == null ? l.price : Math.max(max, l.price);
  }
  return {
    categories: Object.entries(cats).map(([slug, count]) => ({ slug, count })),
    sizes: Object.entries(sizes).sort(([a], [b]) => a.localeCompare(b)).map(([size, count]) => ({ size, count })),
    price: { min, max },
  };
}

/* ---------- Search by image ---------- */
function rankPool(doc) {
  return Object.values(doc.listings).filter((l) => l.status === 'active').map((l) => ({
    id: l.id, brand_slug: l.brand, brandName: brandName(doc, l.brand), title: l.title, category: l.category,
    categoryName: CATEGORY_NAME[l.category], colors: l.colors, description: l.description, size: l.size, price: l.price,
  }));
}
function rankedCards(doc, item, mode, limit, exclude = new Set(), pool = rankPool(doc)) {
  return rank(pool, item, { mode, limit: limit + exclude.size }).filter((h) => !exclude.has(h.id)).slice(0, limit)
    .map((h) => ({ ...card(doc, doc.listings[h.id]), similarity: h.similarity }));
}
function bothSections(doc, item) {
  const pool = rankPool(doc);
  const exact = rankedCards(doc, item, 'exact', 24, new Set(), pool);
  const similar = rankedCards(doc, item, 'similar', 36, new Set(exact.map((e) => e.id)), pool);
  return { exact, similar };
}
function visionRef(doc) {
  return { categories: CATEGORIES, brands: allBrands(doc).map((b) => ({ slug: b.slug, name: b.name })), colors: COLORS };
}
function sanitizeItem(doc, it = {}) {
  const list = (a, n = 20) => (Array.isArray(a) ? a.slice(0, n).map((s) => str(s, 80)).filter(Boolean) : []);
  const brands = new Set(allBrands(doc).map((b) => b.slug));
  return {
    category: CATEGORY_NAME[it.category] ? it.category : '',
    label: str(it.label, 120),
    brand: it.brand && brands.has(String(it.brand)) ? String(it.brand) : 'unknown',
    brand_other: str(it.brand_other, 80),
    brand_confidence: Math.max(0, Math.min(1, Number(it.brand_confidence) || 0)),
    brand_evidence: str(it.brand_evidence, 300),
    model: str(it.model, 80),
    colors: list(it.colors, 5).filter((c) => COLORS[c]),
    fit: str(it.fit, 60),
    materials: list(it.materials), details: list(it.details), patterns: list(it.patterns),
    logos_text: list(it.logos_text), keywords: list(it.keywords),
  };
}

/* WANTED: notify when a matching item is listed (runs inside a transaction) */
function notifyWanted(doc, listingId) {
  const l = doc.listings[listingId];
  if (!l || l.status !== 'active') return;
  const target = rankPool({ ...doc, listings: { [l.id]: l } });
  for (const w of Object.values(doc.wanted)) {
    if (w.userId === l.sellerId) continue;
    if (w.maxPrice && l.price > w.maxPrice) continue;
    if (w.size && normText(w.size) !== normText(l.size)) continue;
    const [hit] = rank(target, w.criteria, { mode: 'similar', limit: 1 });
    if (hit && hit.similarity >= 70) {
      const id = randomUUID();
      doc.notifications[id] = { id, userId: w.userId, title: `WANTED · ${w.label}`, body: `${brandName(doc, l.brand)} · ${l.title} was just listed (€${l.price}).`, href: `item.html?id=${l.id}`, seen: false, createdAt: now() };
    }
  }
}

/* ---------- Photos ---------- */
const MAGIC = { 'image/jpeg': [[0xff, 0xd8, 0xff], 'jpg'], 'image/png': [[0x89, 0x50, 0x4e, 0x47], 'png'], 'image/webp': [[0x52, 0x49, 0x46, 0x46], 'webp'] };
const CONTENT_TYPE = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };
function decodeImage(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) fail(400, 'Unsupported photo format (JPEG, PNG or WebP).');
  const buf = Buffer.from(m[2], 'base64');
  const [sig, ext] = MAGIC[m[1]];
  if (!sig.every((b, i) => buf[i] === b)) fail(400, 'Invalid image file.');
  return { buf, ext };
}

/* AI status: honest about whether image recognition is actually connected. */
let aiState = process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_AUTH_TOKEN ? 'configured' : 'not-configured';

/* ---------- Router ---------- */
async function route(req, ctx) {
  const url = new URL(req.url);
  let path;
  try { path = decodeURIComponent(url.pathname); } catch { fail(400, 'Invalid URL.'); }
  const method = req.method;
  const storage = ctx.storage;
  const ip = ctx.ip || 'unknown';
  const q = Object.fromEntries(url.searchParams);
  let m;

  /* Uploaded photos */
  if (method === 'GET' && (m = /^\/uploads\/([\w-]+(?:_t)?)\.(jpg|png|webp)$/.exec(path))) {
    const f = await storage.getFile(`${m[1]}.${m[2]}`);
    if (!f) return json(404, { error: 'Not found.' });
    return new Response(f.body, { status: 200, headers: { 'Content-Type': CONTENT_TYPE[m[2]], 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' } });
  }
  if (!path.startsWith('/api/')) return json(404, { error: 'Page not found.' });

  // CSRF protection: every write must come from our own JavaScript (custom header).
  if (method !== 'GET' && req.headers.get('x-ff-request') !== '1') fail(403, 'Request refused.');

  const { doc } = await storage.read();
  const me = currentUser(doc, req);
  const auth = () => me || fail(401, 'Please sign in to continue.');
  const cookieOpts = ctx.secure;

  /* Reference data */
  if (method === 'GET' && path === '/api/reference') {
    return json(200, { categories: CATEGORIES, sizes: SIZES, conditions: CONDITIONS, colors: COLORS, brands: allBrands(doc) });
  }
  if (method === 'GET' && path === '/api/status') {
    return json(200, { ai: aiState, model: MODEL, listings: Object.values(doc.listings).filter((l) => l.status === 'active').length });
  }

  /* Accounts */
  if (method === 'GET' && path === '/api/me') {
    if (!me) return json(200, { user: null });
    const unread = Object.values(doc.notifications).filter((n) => n.userId === me.id && !n.seen).length;
    return json(200, { user: { ...publicUser(doc, me), email: me.email, unread } });
  }
  if (method === 'POST' && path === '/api/auth/signup') {
    if (!rateLimit(`signup:${ip}`, 10, 3600000)) fail(429, 'Too many attempts, please try again later.');
    const b = await readBody(req);
    const username = str(b.username, 24);
    const email = str(b.email, 120).toLowerCase();
    const password = String(b.password || '');
    if (!/^[a-zA-Z0-9._-]{3,24}$/.test(username)) fail(400, 'Username: 3 to 24 characters (letters, numbers, . _ -).');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'Invalid email address.');
    if (password.length < 8) fail(400, 'Password: 8 characters minimum.');
    const passHash = await hashPassword(password);
    const token = newToken();
    await transact(storage, (d) => {
      if (userByName(d, username)) fail(409, 'This username is already taken.');
      if (Object.values(d.users).some((u) => u.email === email)) fail(409, 'An account already exists with this email.');
      const id = d.nextUserId++;
      d.users[id] = { id, username, email, passHash, bio: '', city: '', avatarId: null, createdAt: now() };
      d.sessions[sha(token)] = { userId: id, expiresAt: new Date(Date.now() + SESSION_DAYS * 86400000).toISOString() };
    });
    return json(201, { ok: true }, { 'Set-Cookie': sessionCookie(token, cookieOpts) });
  }
  if (method === 'POST' && path === '/api/auth/login') {
    if (!rateLimit(`login:${ip}`, 10, 600000)) fail(429, 'Too many attempts, please try again in 10 minutes.');
    const b = await readBody(req);
    const login = str(b.login, 120).toLowerCase();
    const u = Object.values(doc.users).find((x) => x.username.toLowerCase() === login || x.email === login);
    if (!u || !(await verifyPassword(String(b.password || ''), u.passHash))) fail(401, 'Incorrect username/email or password.');
    const token = newToken();
    await transact(storage, (d) => {
      const t = now();
      for (const [k, s] of Object.entries(d.sessions)) if (s.expiresAt < t) delete d.sessions[k];
      d.sessions[sha(token)] = { userId: u.id, expiresAt: new Date(Date.now() + SESSION_DAYS * 86400000).toISOString() };
    });
    return json(200, { ok: true }, { 'Set-Cookie': sessionCookie(token, cookieOpts) });
  }
  if (method === 'POST' && path === '/api/auth/logout') {
    const token = readCookie(req);
    if (token) await transact(storage, (d) => { delete d.sessions[sha(token)]; });
    return json(200, { ok: true }, { 'Set-Cookie': sessionCookie(null, cookieOpts) });
  }
  if (method === 'PATCH' && path === '/api/me') {
    const u = auth();
    const b = await readBody(req);
    await transact(storage, (d) => {
      const x = d.users[u.id];
      if (b.avatarId !== undefined) {
        const p = b.avatarId ? d.photos[str(b.avatarId, 40)] : null;
        if (b.avatarId && (!p || p.ownerId !== u.id || p.listingId)) fail(400, 'Invalid profile photo.');
        x.avatarId = b.avatarId || null;
      }
      x.bio = str(b.bio ?? x.bio, 600);
      x.city = str(b.city ?? x.city, 60);
    });
    return json(200, { ok: true });
  }

  /* Photos (uploaded from the seller's own device) */
  if (method === 'POST' && path === '/api/photos') {
    const u = auth();
    if (!rateLimit(`photo:${u.id}`, 80, 600000)) fail(429, 'Too many photos uploaded, please wait a few minutes.');
    const b = await readBody(req, 6 * 1024 * 1024);
    const full = decodeImage(b.full);
    const thumb = decodeImage(b.thumb);
    const w = Math.round(Number(b.width)), h = Math.round(Number(b.height));
    if (!(w > 0 && h > 0 && w <= 4096 && h <= 4096)) fail(400, 'Invalid photo dimensions.');
    const minPx = b.purpose === 'avatar' ? 200 : 600;
    if (w < minPx && h < minPx) fail(400, `Photo too small: ${minPx} px minimum for a sharp image.`);
    const id = randomBytes(12).toString('base64url');
    await storage.putFile(`${id}.${full.ext}`, full.buf);
    await storage.putFile(`${id}_t.${full.ext}`, thumb.buf);
    await transact(storage, (d) => { d.photos[id] = { id, ownerId: u.id, listingId: null, position: 0, width: w, height: h, ext: full.ext, createdAt: now() }; });
    return json(201, { id, url: `/uploads/${id}.${full.ext}`, thumb: `/uploads/${id}_t.${full.ext}`, width: w, height: h });
  }

  /* Brands */
  if (method === 'GET' && path === '/api/brands') return json(200, allBrands(doc));
  if (method === 'GET' && (m = /^\/api\/brands\/([\w-]+)$/.exec(path))) {
    const b = allBrands(doc).find((x) => x.slug === m[1]);
    return b ? json(200, b) : fail(404, 'Brand not found.');
  }

  /* Listings */
  if (method === 'GET' && path === '/api/listings') return json(200, searchListings(doc, q));
  if (method === 'GET' && path === '/api/facets') return json(200, facets(doc, q));
  if (method === 'POST' && path === '/api/listings') {
    const u = auth();
    if (!rateLimit(`list:${u.id}`, 30, 3600000)) fail(429, 'Too many listings published in a short time.');
    const body = await readBody(req);
    const id = randomBytes(6).toString('base64url');
    await transact(storage, (d) => {
      const v = validateListing(d, body, u);
      const t = now();
      d.listings[id] = {
        id, sellerId: u.id, brand: v.brand, title: v.title, category: v.category, size: v.size, condition: v.condition,
        price: v.price, negotiable: v.negotiable, hasProof: v.hasProof, description: v.description, colors: v.colors,
        status: 'active', views: 0, favorites: 0, buyerId: null, photoIds: v.photoIds, createdAt: t, updatedAt: t, soldAt: null,
      };
      attachPhotos(d, id, v.photoIds);
      notifyWanted(d, id);
    });
    return json(201, { id });
  }
  if ((m = /^\/api\/listings\/([\w-]+)$/.exec(path))) {
    const l = doc.listings[m[1]];
    if (!l || (l.status === 'removed' && (!me || me.id !== l.sellerId))) fail(404, 'Listing not found.');
    const owner = !!(me && me.id === l.sellerId);
    if (method === 'GET') {
      if (!owner) {
        const bump = transact(storage, (d) => { if (d.listings[l.id]) d.listings[l.id].views += 1; }, { retries: 1, optional: true }).catch(() => {});
        if (ctx.waitUntil) ctx.waitUntil(bump); // keep the serverless function alive until the view is saved
      }
      const photos = l.photoIds.map((id) => doc.photos[id]).filter(Boolean)
        .map((p) => ({ id: p.id, url: photoUrl(p), thumb: photoUrl(p, true), w: p.width, h: p.height }));
      return json(200, {
        ...card(doc, l),
        condition: COND_NAME[l.condition], conditionSlug: l.condition, brandSlug: l.brand,
        description: l.description, colors: l.colors, views: l.views, photos,
        seller: publicUser(doc, doc.users[l.sellerId]), isOwner: owner,
        isFavorite: !!(me && (doc.favorites[me.id] || []).includes(l.id)),
        soldTo: owner && l.buyerId ? doc.users[l.buyerId]?.username : undefined,
      });
    }
    if (method === 'PATCH') {
      const u = auth();
      if (!owner) fail(403, 'This is not your listing.');
      const body = await readBody(req);
      await transact(storage, (d) => {
        const v = validateListing(d, body, u, l.id);
        Object.assign(d.listings[l.id], {
          brand: v.brand, title: v.title, category: v.category, size: v.size, condition: v.condition, price: v.price,
          negotiable: v.negotiable, hasProof: v.hasProof, description: v.description, colors: v.colors, photoIds: v.photoIds, updatedAt: now(),
        });
        attachPhotos(d, l.id, v.photoIds);
      });
      return json(200, { id: l.id });
    }
  }
  if (method === 'POST' && (m = /^\/api\/listings\/([\w-]+)\/status$/.exec(path))) {
    const u = auth();
    const b = await readBody(req);
    if (!['active', 'sold', 'removed'].includes(b.status)) fail(400, 'Invalid status.');
    await transact(storage, (d) => {
      const l = d.listings[m[1]];
      if (!l || l.sellerId !== u.id) fail(404, 'Listing not found.');
      let buyer = null;
      if (b.status === 'sold' && b.buyer) {
        buyer = userByName(d, str(b.buyer, 24));
        if (!buyer) fail(400, 'Buyer not found: check their username.');
        if (buyer.id === u.id) fail(400, 'You cannot be your own buyer.');
      }
      const wasActive = l.status === 'active';
      l.status = b.status;
      l.buyerId = b.status === 'sold' ? buyer?.id ?? null : null;
      l.soldAt = b.status === 'sold' ? now() : null;
      l.updatedAt = now();
      if (buyer) {
        const id = randomUUID();
        d.notifications[id] = { id, userId: buyer.id, title: 'Purchase confirmed', body: `${u.username} confirmed your purchase of “${l.title}”. You can now leave a review.`, href: 'account.html#purchases', seen: false, createdAt: now() };
      }
      if (b.status === 'active' && !wasActive) notifyWanted(d, l.id);
    });
    return json(200, { ok: true });
  }
  if (method === 'POST' && (m = /^\/api\/listings\/([\w-]+)\/favorite$/.exec(path))) {
    const u = auth();
    const res = await transact(storage, (d) => {
      const l = d.listings[m[1]];
      if (!l || l.status === 'removed') fail(404, 'Listing not found.');
      const favs = (d.favorites[u.id] ||= []);
      const i = favs.indexOf(l.id);
      if (i >= 0) { favs.splice(i, 1); l.favorites = Math.max(0, (l.favorites || 0) - 1); } else { favs.unshift(l.id); l.favorites = (l.favorites || 0) + 1; }
      return { favorite: i < 0, count: l.favorites };
    });
    return json(200, res);
  }

  /* Personal space */
  if (method === 'GET' && path === '/api/me/listings') {
    const u = auth();
    return json(200, Object.values(doc.listings).filter((l) => l.sellerId === u.id && l.status !== 'removed')
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
      .map((l) => ({ ...card(doc, l), views: l.views, buyer: l.buyerId ? doc.users[l.buyerId]?.username || null : null })));
  }
  if (method === 'GET' && path === '/api/me/favorites') {
    const u = auth();
    return json(200, (doc.favorites[u.id] || []).map((id) => doc.listings[id]).filter((l) => l && l.status !== 'removed').map((l) => card(doc, l)));
  }
  if (method === 'GET' && path === '/api/me/purchases') {
    const u = auth();
    return json(200, Object.values(doc.listings).filter((l) => l.buyerId === u.id)
      .sort((a, b) => ((a.soldAt || '') < (b.soldAt || '') ? 1 : -1))
      .map((l) => ({ ...card(doc, l), reviewed: !!doc.reviews[l.id] })));
  }

  /* Seller profiles */
  if (method === 'GET' && (m = /^\/api\/users\/([\w.-]+)$/.exec(path))) {
    const u = userByName(doc, m[1]);
    if (!u) fail(404, 'Seller not found.');
    const listings = (status) => Object.values(doc.listings).filter((l) => l.sellerId === u.id && l.status === status)
      .sort((a, b) => ((a.soldAt || a.createdAt) < (b.soldAt || b.createdAt) ? 1 : -1)).slice(0, 120).map((l) => card(doc, l));
    const reviews = Object.values(doc.reviews).filter((r) => r.sellerId === u.id)
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
      .map((r) => ({ rating: r.rating, comment: r.comment, created_at: r.createdAt, buyer: doc.users[r.buyerId]?.username || 'deleted', title: doc.listings[r.listingId]?.title || '' }));
    return json(200, { ...publicUser(doc, u), active: listings('active'), sold: listings('sold'), reviews, isMe: !!(me && me.id === u.id) });
  }

  /* Reviews: only the buyer named by the seller, once per item */
  if (method === 'POST' && path === '/api/reviews') {
    const u = auth();
    const b = await readBody(req);
    const rating = Math.round(Number(b.rating));
    await transact(storage, (d) => {
      const l = d.listings[str(b.listingId, 40)];
      if (!l || l.status !== 'sold' || l.buyerId !== u.id) fail(403, 'Only the buyer of this item can leave a review.');
      if (d.reviews[l.id]) fail(409, 'You have already reviewed this purchase.');
      if (!(rating >= 1 && rating <= 5)) fail(400, 'Rating must be between 1 and 5.');
      d.reviews[l.id] = { listingId: l.id, sellerId: l.sellerId, buyerId: u.id, rating, comment: str(b.comment, 1000), createdAt: now() };
    });
    return json(201, { ok: true });
  }

  /* Search by image */
  if (method === 'POST' && path === '/api/visual-search') {
    if (!rateLimit(`vs:${ip}`, 20, 600000)) fail(429, 'Too many searches, please wait a few minutes.');
    const b = await readBody(req, 6 * 1024 * 1024);
    const m2 = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(b.image || '');
    if (!m2) fail(400, 'Invalid image: JPEG, PNG, WebP or GIF expected.');
    try {
      const t0 = Date.now();
      const analysis = await analyzeImage(visionRef(doc), { mediaType: m2[1], data: m2[2] });
      aiState = 'connected';
      const fresh = (await storage.read()).doc;
      const items = (analysis.items || []).map((it) => sanitizeItem(fresh, it));
      return json(200, {
        engine: 'ai', model: analysis.model || MODEL, ms: Date.now() - t0, isFashion: !!analysis.is_fashion,
        summary: str(analysis.summary, 600), items, ...(items.length ? bothSections(fresh, items[0]) : { exact: [], similar: [] }),
      });
    } catch (e) {
      if (e instanceof VisionUnavailable) {
        aiState = 'unavailable';
        return json(503, { error: 'ai-unavailable', message: 'AI image recognition is not connected on this server (no Anthropic API key configured).', detail: e.message });
      }
      throw e;
    }
  }
  if (method === 'POST' && path === '/api/rank') {
    const b = await readBody(req);
    return json(200, bothSections(doc, sanitizeItem(doc, b.item)));
  }

  /* WANTED ITEMS */
  if (path === '/api/wanted') {
    const u = auth();
    if (method === 'GET') {
      const pool = rankPool(doc);
      return json(200, Object.values(doc.wanted).filter((w) => w.userId === u.id).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)).map((w) => {
        const matches = rank(pool, w.criteria, { mode: 'similar', limit: 8 }).filter((h) => h.similarity >= 70)
          .map((h) => ({ ...card(doc, doc.listings[h.id]), similarity: h.similarity }))
          .filter((c) => (!w.maxPrice || c.price <= w.maxPrice) && (!w.size || normText(w.size) === normText(c.size)));
        return { id: w.id, label: w.label, thumb: w.thumb, size: w.size, maxPrice: w.maxPrice, createdAt: w.createdAt, criteria: w.criteria, matches };
      }));
    }
    if (method === 'POST') {
      const b = await readBody(req, 512 * 1024);
      const id = randomUUID();
      const label = str(b.label, 120) || 'Wanted item';
      const thumb = typeof b.thumb === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(b.thumb) && b.thumb.length < 200000 ? b.thumb : null;
      await transact(storage, (d) => {
        d.wanted[id] = { id, userId: u.id, label, criteria: sanitizeItem(d, b.criteria), thumb, size: str(b.size, 20), maxPrice: Number(b.maxPrice) > 0 ? Math.round(Number(b.maxPrice)) : null, createdAt: now() };
      });
      return json(201, { id, label });
    }
  }
  if (method === 'DELETE' && (m = /^\/api\/wanted\/([\w-]+)$/.exec(path))) {
    const u = auth();
    await transact(storage, (d) => { if (d.wanted[m[1]]?.userId === u.id) delete d.wanted[m[1]]; });
    return json(204);
  }

  /* Notifications */
  if (method === 'GET' && path === '/api/notifications') {
    if (!me) return json(200, []);
    return json(200, Object.values(doc.notifications).filter((n) => n.userId === me.id && !n.seen)
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)).slice(0, 20)
      .map((n) => ({ id: n.id, title: n.title, body: n.body, href: n.href, created_at: n.createdAt })));
  }
  if (method === 'POST' && path === '/api/notifications/seen') {
    const u = auth();
    const { ids = [] } = await readBody(req);
    await transact(storage, (d) => {
      for (const id of ids.slice(0, 50)) { const n = d.notifications[String(id)]; if (n && n.userId === u.id) n.seen = true; }
    });
    return json(204);
  }

  fail(404, 'Unknown route.');
}

/** Entry point: handle(Request, { storage, ip, secure }) → Response */
export async function handle(req, ctx) {
  try {
    return await route(req, ctx);
  } catch (e) {
    if (e instanceof HttpError) return json(e.status, { error: e.message });
    console.error(e);
    return json(500, { error: 'Server error.' });
  }
}
