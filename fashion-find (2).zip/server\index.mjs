// FASHION FIND — local server: serves public/ and the API (server/app.mjs).
// Usage: npm start   (port 8090, or PORT=xxxx). Data: data/db.json + data/uploads/.
// Online, the same API runs as a Netlify Function (netlify/functions/api.mjs).
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { handle } from './app.mjs';
import { localStorage } from './storage.mjs';
import { MODEL } from './vision.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC = join(ROOT, 'public');
const PORT = Number(process.env.PORT || process.argv[2]) || 8090;
const storage = localStorage(join(ROOT, 'data'));
const secure = process.env.FF_SECURE_COOKIE === '1';

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8',
};

function body(req) {
  return new Promise((ok, ko) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => { size += c.length; if (size > 7 * 1024 * 1024) { req.destroy(); ko(new Error('too large')); } else chunks.push(c); });
    req.on('end', () => ok(Buffer.concat(chunks)));
    req.on('error', ko);
  });
}

createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  try {
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/uploads/')) {
      const hasBody = !['GET', 'HEAD'].includes(req.method);
      const request = new Request(url, { method: req.method, headers: req.headers, body: hasBody ? await body(req) : undefined });
      const response = await handle(request, { storage, ip: req.socket.remoteAddress, secure });
      const headers = Object.fromEntries(response.headers);
      const cookies = response.headers.getSetCookie();
      if (cookies.length) headers['set-cookie'] = cookies;
      res.writeHead(response.status, headers);
      res.end(Buffer.from(await response.arrayBuffer()));
      return;
    }
    let path = decodeURIComponent(url.pathname);
    const file = normalize(join(PUBLIC, path.endsWith('/') ? `${path}index.html` : path));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403).end('Forbidden'); return; }
    const data = await readFile(file);
    res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  } catch (e) {
    if (e.code === 'ENOENT' || e.code === 'EISDIR') { res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Page not found'); return; }
    if (e.message === 'too large') { res.writeHead(413).end('Request too large'); return; }
    console.error(e);
    res.writeHead(500).end('Server error');
  }
}).listen(PORT, () => console.log(`Fashion Find : http://localhost:${PORT}  (vision : ${MODEL})`));
