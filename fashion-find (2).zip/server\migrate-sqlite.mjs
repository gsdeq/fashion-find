// One-time import of the previous SQLite database (data/fashion-find.db) into data/db.json.
// Runs automatically on the first local start if db.json does not exist yet. Photos files are unchanged.
export async function migrateSqlite(file, doc) {
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(file, { readOnly: true });
  const all = (sql) => { try { return db.prepare(sql).all(); } catch { return []; } };

  let maxId = 0;
  for (const u of all('SELECT * FROM users')) {
    doc.users[u.id] = { id: u.id, username: u.username, email: u.email, passHash: u.pass_hash, bio: u.bio || '', city: u.city || '', avatarId: u.avatar_id || null, createdAt: u.created_at };
    maxId = Math.max(maxId, u.id);
  }
  doc.nextUserId = maxId + 1;
  for (const b of all('SELECT * FROM brands WHERE user_added = 1')) {
    doc.brandsAdded.push({ slug: b.slug, name: b.name, origin: '', createdBy: b.created_by, createdAt: b.created_at });
  }
  for (const p of all('SELECT * FROM photos')) {
    doc.photos[p.id] = { id: p.id, ownerId: p.owner_id, listingId: p.listing_id || null, position: p.position, width: p.width, height: p.height, ext: p.ext, createdAt: p.created_at };
  }
  for (const l of all('SELECT * FROM listings')) {
    doc.listings[l.id] = {
      id: l.id, sellerId: l.seller_id, brand: l.brand_slug, title: l.title, category: l.category, size: l.size, condition: l.condition,
      price: l.price, negotiable: !!l.negotiable, hasProof: !!l.has_proof, description: l.description, colors: JSON.parse(l.colors || '[]'),
      status: l.status, views: l.views || 0, favorites: 0, buyerId: l.buyer_id || null,
      photoIds: Object.values(doc.photos).filter((p) => p.listingId === l.id).sort((a, b) => a.position - b.position).map((p) => p.id),
      createdAt: l.created_at, updatedAt: l.updated_at, soldAt: l.sold_at || null,
    };
  }
  for (const f of all('SELECT * FROM favorites')) {
    (doc.favorites[f.user_id] ||= []).push(f.listing_id);
    if (doc.listings[f.listing_id]) doc.listings[f.listing_id].favorites += 1;
  }
  for (const r of all('SELECT * FROM reviews')) {
    doc.reviews[r.listing_id] = { listingId: r.listing_id, sellerId: r.seller_id, buyerId: r.buyer_id, rating: r.rating, comment: r.comment || '', createdAt: r.created_at };
  }
  for (const w of all('SELECT * FROM wanted')) {
    doc.wanted[w.id] = { id: w.id, userId: w.user_id, label: w.label, criteria: JSON.parse(w.criteria), thumb: w.thumb, size: w.size || '', maxPrice: w.max_price, createdAt: w.created_at };
  }
  for (const n of all('SELECT * FROM notifications')) {
    doc.notifications[n.id] = { id: n.id, userId: n.user_id, title: n.title, body: n.body, href: n.href, seen: !!n.seen, createdAt: n.created_at };
  }
  db.close();
  return doc;
}
