/* FASHION FIND — marketplace client: reference data, listing cards, search & filters. */
(function () {
  var E = FF.esc;
  var refPromise = null;
  var REF = null;

  function ref() {
    if (!refPromise) refPromise = FF.api('/api/reference').then(function (r) {
      REF = r;
      r.cat = {}; r.categories.forEach(function (c) { r.cat[c.slug] = c; });
      r.brand = {}; r.brands.forEach(function (b) { r.brand[b.slug] = b; });
      r.cond = {}; r.conditions.forEach(function (c) { r.cond[c.slug] = c; });
      return r;
    });
    return refPromise;
  }

  function price(n) { return '€' + Number(n).toLocaleString('en-GB'); }
  function date(iso) { return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }); }

  function noPhoto(cls) { return '<div class="nophoto ' + (cls || '') + '"><span>No photo available</span></div>'; }

  function card(p, opts) {
    opts = opts || {};
    var media = p.photo
      ? '<img src="' + E(p.photo.thumb) + '" alt="' + E(p.brand.name + ' ' + p.title) + '" loading="lazy" width="' + p.photo.w + '" height="' + p.photo.h + '">'
      : noPhoto();
    var sim = opts.similarity != null ? '<span class="pcard__sim">' + opts.similarity + '%<small> match</small></span>' : '';
    var badge = p.status === 'sold' ? '<span class="pcard__badge">Sold</span>' : '';
    return '<article class="pcard">' +
      '<a class="pcard__media" href="item.html?id=' + encodeURIComponent(p.id) + '" tabindex="-1">' + media + sim + badge + '</a>' +
      '<div class="pcard__body">' +
        '<a class="pcard__brand" href="designer.html?b=' + encodeURIComponent(p.brand.slug) + '">' + E(p.brand.name) + '</a>' +
        '<a class="pcard__name" href="item.html?id=' + encodeURIComponent(p.id) + '">' + E(p.title) + '</a>' +
        '<div class="pcard__meta"><span>' + E(p.size) + '</span><span>' + E(p.condition) + '</span></div>' +
        '<div class="pcard__row"><span class="pcard__price">' + price(p.price) + (p.negotiable ? ' <small>neg.</small>' : '') + '</span>' +
          (p.seller ? '<a class="pcard__seller" href="profile.html?u=' + encodeURIComponent(p.seller.username) + '">@' + E(p.seller.username) + '</a>' : '') + '</div>' +
        (opts.viewButton ? '<a class="btn btn--ghost btn--sm pcard__view" href="item.html?id=' + encodeURIComponent(p.id) + '">View item</a>' : '') +
      '</div></article>';
  }

  function grid(list, opts) { return list.map(function (p) { return card(p, opts); }).join(''); }

  /* ---------- Search + filters (Shop, designer pages) ---------- */
  function browser(root, opts) {
    opts = opts || {};
    var params = new URLSearchParams(location.search);
    var keys = ['q', 'brand', 'category', 'size', 'color', 'condition', 'min', 'max', 'sort'];
    var st = {};
    keys.forEach(function (k) { st[k] = params.get(k) || ''; });
    if (opts.brand) st.brand = opts.brand;
    var page = 1;

    return ref().then(function (R) {
      root.innerHTML =
        '<div class="filters">' +
          '<div class="chips" data-chips role="group" aria-label="Categories"></div>' +
          '<div class="filters__row">' +
            '<label class="field field--grow"><span class="label">Search</span><input type="search" data-f="q" placeholder="Brand, item, model, material…" value="' + E(st.q) + '"></label>' +
            (opts.brand ? '' : '<label class="field"><span class="label">Brand</span><select data-f="brand"><option value="">All brands</option>' +
              R.groups_html + '</select></label>') +
            '<label class="field"><span class="label">Size</span><select data-f="size"><option value="">All sizes</option></select></label>' +
            '<label class="field"><span class="label">Color</span><select data-f="color"><option value="">All colors</option>' +
              Object.keys(R.colors).map(function (k) { return '<option value="' + k + '">' + E(R.colors[k].name) + '</option>'; }).join('') + '</select></label>' +
            '<label class="field"><span class="label">Condition</span><select data-f="condition"><option value="">Any condition</option>' +
              R.conditions.map(function (c) { return '<option value="' + c.slug + '">' + E(c.name) + '</option>'; }).join('') + '</select></label>' +
            '<label class="field field--sm"><span class="label">Min €</span><input type="number" min="0" inputmode="numeric" data-f="min" value="' + E(st.min) + '"></label>' +
            '<label class="field field--sm"><span class="label">Max €</span><input type="number" min="0" inputmode="numeric" data-f="max" value="' + E(st.max) + '"></label>' +
            '<label class="field"><span class="label">Sort</span><select data-f="sort"><option value="">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option><option value="popular">Most popular</option></select></label>' +
          '</div>' +
        '</div>' +
        '<div class="results-bar"><p class="results-count" aria-live="polite"></p><button class="linkbtn" type="button" data-reset>Clear filters</button></div>' +
        '<div class="pgrid" data-grid></div>' +
        '<div class="more"><button class="btn btn--ghost" type="button" data-more hidden>Load more</button></div>';

      var gridEl = root.querySelector('[data-grid]');
      var count = root.querySelector('.results-count');
      var more = root.querySelector('[data-more]');
      var sizeSel = root.querySelector('[data-f=size]');
      var chips = root.querySelector('[data-chips]');
      var timer;

      function facets() {
        return FF.api('/api/facets' + (st.brand ? '?brand=' + encodeURIComponent(st.brand) : '')).then(function (f) {
          var counts = {};
          f.categories.forEach(function (c) { counts[c.slug] = c.count; });
          var total = f.categories.reduce(function (s, c) { return s + c.count; }, 0);
          chips.innerHTML = '<button class="chip" type="button" data-cat="">All <span>' + total + '</span></button>' +
            R.categories.map(function (c) { return '<button class="chip" type="button" data-cat="' + c.slug + '">' + E(c.name) + ' <span>' + (counts[c.slug] || 0) + '</span></button>'; }).join('');
          chips.querySelectorAll('.chip').forEach(function (c) {
            c.addEventListener('click', function () { st.category = c.getAttribute('data-cat'); load(true); });
          });
          sizeSel.innerHTML = '<option value="">All sizes</option>' + f.sizes.map(function (s) { return '<option>' + E(s.size) + '</option>'; }).join('');
          sizeSel.value = st.size;
          markChips();
        });
      }
      function markChips() { chips.querySelectorAll('.chip').forEach(function (c) { c.setAttribute('aria-pressed', c.getAttribute('data-cat') === st.category ? 'true' : 'false'); }); }

      function load(reset) {
        if (reset) page = 1;
        markChips();
        var qs = new URLSearchParams();
        keys.forEach(function (k) { if (st[k]) qs.set(k, st[k]); });
        var shown = new URLSearchParams(qs);
        if (opts.brand) { shown.delete('brand'); shown.set('b', opts.brand); }
        history.replaceState(null, '', location.pathname + (shown.toString() ? '?' + shown : ''));
        qs.set('page', page);
        if (reset) gridEl.innerHTML = '<div class="skeleton pcard-skel"></div><div class="skeleton pcard-skel"></div><div class="skeleton pcard-skel"></div>';
        return FF.api('/api/listings?' + qs).then(function (res) {
          count.textContent = res.total + (res.total === 1 ? ' item' : ' items') + ' for sale';
          if (reset) gridEl.innerHTML = '';
          if (!res.total) {
            var filtered = keys.some(function (k) { return k !== 'sort' && st[k] && !(opts.brand && k === 'brand'); });
            gridEl.innerHTML = '<div class="empty">' + (filtered
              ? '<p>No item matches these filters yet.</p><a class="btn btn--ghost" href="search.html">Search by image</a>'
              : '<p>' + (opts.emptyText || 'No listings yet.') + '</p><a class="btn btn--blue" href="sell.html">Sell an item</a>') + '</div>';
          } else {
            gridEl.insertAdjacentHTML('beforeend', grid(res.items));
          }
          more.hidden = res.page * res.pageSize >= res.total;
        }).catch(function (e) { gridEl.innerHTML = '<div class="empty"><p>' + E(e.message) + '</p></div>'; });
      }

      root.querySelectorAll('[data-f]').forEach(function (el) {
        var k = el.getAttribute('data-f');
        if (el.tagName === 'SELECT') el.value = st[k];
        el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', function () {
          st[k] = el.value.trim();
          clearTimeout(timer);
          timer = setTimeout(function () { if (k === 'brand') facets(); load(true); }, el.tagName === 'INPUT' ? 280 : 0);
        });
      });
      root.querySelector('[data-reset]').addEventListener('click', function () {
        keys.forEach(function (k) { if (!(opts.brand && k === 'brand')) st[k] = ''; });
        root.querySelectorAll('[data-f]').forEach(function (el) { el.value = ''; });
        facets(); load(true);
      });
      more.addEventListener('click', function () { page += 1; load(false); });
      facets();
      return load(true);
    });
  }

  /* Brand <option>s grouped Designer / Underground / Footwear / added by sellers */
  function brandOptions(R, selected) {
    var groups = [['designer', 'Designer / Luxury'], ['underground', 'Underground / Streetwear'], ['footwear', 'Sneakers / Footwear']];
    var html = groups.map(function (g) {
      return '<optgroup label="' + g[1] + '">' + R.brands.filter(function (b) { return b.group === g[0] && !b.user_added; })
        .map(function (b) { return '<option value="' + b.slug + '"' + (b.slug === selected ? ' selected' : '') + '>' + E(b.name) + '</option>'; }).join('') + '</optgroup>';
    }).join('');
    var added = R.brands.filter(function (b) { return b.user_added; });
    if (added.length) html += '<optgroup label="Added by sellers">' + added.map(function (b) { return '<option value="' + b.slug + '"' + (b.slug === selected ? ' selected' : '') + '>' + E(b.name) + '</option>'; }).join('') + '</optgroup>';
    return html;
  }

  var _ref = ref;
  ref = function () { return _ref().then(function (R) { R.groups_html = brandOptions(R); return R; }); };

  window.FFMarket = { ref: ref, card: card, grid: grid, browser: browser, price: price, date: date, noPhoto: noPhoto, brandOptions: brandOptions };
})();
