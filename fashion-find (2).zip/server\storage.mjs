// FASHION FIND — storage.
// The marketplace data lives in one JSON document, written with optimistic concurrency:
// every change re-reads the latest version and is saved only if nobody else saved in between
// (otherwise it is retried). Photos are stored as separate files/blobs.
//
//   localStorage(dir)  → data/db.json + data/uploads/   (npm start on your computer)
//   netlifyStorage()   → Netlify Blobs stores "ff-data" and "ff-photos"   (Netlify)

import { readFile, writeFile, rename, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

export function emptyDoc() {
  return {
    version: 1,
    users: {}, sessions: {}, brandsAdded: [], listings: {}, photos: {},
    favorites: {}, reviews: {}, wanted: {}, notifications: {}, nextUserId: 1,
  };
}

/* ---------- Local files ---------- */
export function localStorage(dataDir) {
  const dbFile = join(dataDir, 'db.json');
  const uploads = join(dataDir, 'uploads');
  let cache = null;
  let queue = Promise.resolve(); // file writes happen one after another, in commit order
  let n = 0;

  async function load() {
    await mkdir(uploads, { recursive: true });
    if (existsSync(dbFile)) return JSON.parse(await readFile(dbFile, 'utf8'));
    const legacy = join(dataDir, 'fashion-find.db');
    if (existsSync(legacy)) {
      const { migrateSqlite } = await import('./migrate-sqlite.mjs');
      const doc = await migrateSqlite(legacy, emptyDoc());
      await writeFile(dbFile, JSON.stringify(doc));
      return doc;
    }
    return emptyDoc();
  }

  return {
    kind: 'local',
    async read() {
      if (!cache) cache = { doc: await load(), etag: 1 };
      return cache;
    },
    async write(doc, etag) {
      // Version check and claim happen synchronously, so two concurrent writers can never both succeed.
      if (!cache || etag !== cache.etag) return { ok: false };
      cache = { doc, etag: cache.etag + 1 };
      const text = JSON.stringify(doc);
      const tmp = `${dbFile}.${process.pid}.${++n}.tmp`;
      queue = queue.catch(() => {}).then(async () => { await writeFile(tmp, text); await rename(tmp, dbFile); });
      await queue;
      return { ok: true };
    },
    async putFile(key, bytes) {
      await mkdir(uploads, { recursive: true });
      await writeFile(join(uploads, key), bytes);
    },
    async getFile(key) {
      try { return { body: await readFile(join(uploads, key)) }; } catch { return null; }
    },
  };
}

/* ---------- Netlify Blobs ---------- */
export async function netlifyStorage() {
  const { getStore } = await import('@netlify/blobs');
  const data = getStore({ name: 'ff-data', consistency: 'strong' });
  const files = getStore('ff-photos');
  let cache = null; // { doc, etag } kept warm between invocations of the same instance

  return {
    kind: 'netlify',
    async read() {
      const r = await data.getWithMetadata('db', { type: 'json', ...(cache?.etag ? { etag: cache.etag } : {}) });
      if (r === null) { cache = { doc: emptyDoc(), etag: null }; return cache; }
      if (r.data === null && cache) return cache; // unchanged since last read
      if (r.etag) { cache = { doc: r.data, etag: r.etag }; return cache; }
      // No ETag on the read: take it from the listing FIRST, then read the data. The data is then at
      // least as recent as the ETag, so a conditional write can only fail and retry, never overwrite.
      const { blobs } = await data.list({ prefix: 'db' });
      const etag = blobs.find((b) => b.key === 'db')?.etag || null;
      const doc = await data.get('db', { type: 'json' });
      cache = { doc: doc || emptyDoc(), etag };
      return cache;
    },
    async write(doc, etag) {
      const res = await data.setJSON('db', doc, etag ? { onlyIfMatch: etag } : { onlyIfNew: true });
      if (!res.modified) return { ok: false };
      cache = { doc, etag: res.etag };
      return { ok: true };
    },
    async putFile(key, bytes) {
      await files.set(key, bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
    },
    async getFile(key) {
      const buf = await files.get(key, { type: 'arrayBuffer' });
      return buf ? { body: new Uint8Array(buf) } : null;
    },
  };
}
