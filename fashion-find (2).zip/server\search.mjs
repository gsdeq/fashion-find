// FASHION FIND — classement des annonces réelles à partir d'une pièce analysée par l'IA.
//
// Score hybride et explicable, calculé sur les champs saisis par les vendeurs :
//   catégorie · marque · couleurs · mots-clés (titre, description, détails, modèle)
// + emplacement « visuel » (similarité d'embeddings entre la capture et les photos des
//   annonces) branché dès qu'un index vectoriel existe — voir docs/RECHERCHE-VISUELLE.md.
import { COLORS } from './reference.mjs';

const STOP = new Set('the of and with a an in on for to by from x size condition new good excellent fair de du des la le les un une en et avec sans pour'.split(' '));

export function norm(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}
export function tokens(...parts) {
  const out = new Set();
  for (const p of parts.flat(3)) {
    for (const t of norm(p).split(/[^a-z0-9]+/)) {
      if (t.length > 1 && !STOP.has(t)) out.add(t.replace(/s$/, ''));
    }
  }
  return out;
}

const RELATED = {
  'hoodies-sweatshirts': { 't-shirts': 0.25, jackets: 0.2 },
  't-shirts': { 'hoodies-sweatshirts': 0.25 },
  jackets: { 'leather-jackets': 0.6 },
  'leather-jackets': { jackets: 0.6 },
  jeans: { 'baggy-pants': 0.55, trousers: 0.4, 'cargo-pants': 0.3, shorts: 0.2 },
  'baggy-pants': { jeans: 0.55, 'cargo-pants': 0.6, trousers: 0.5 },
  'cargo-pants': { 'baggy-pants': 0.6, trousers: 0.5, jeans: 0.3 },
  trousers: { 'baggy-pants': 0.5, 'cargo-pants': 0.5, jeans: 0.4 },
  shorts: { trousers: 0.25, jeans: 0.2 },
  'shoes-sneakers': { boots: 0.4 },
  boots: { 'shoes-sneakers': 0.4 },
  accessories: { belts: 0.4, sunglasses: 0.4, jewelry: 0.3, bags: 0.2 },
  belts: { accessories: 0.4 },
  sunglasses: { accessories: 0.4 },
  jewelry: { accessories: 0.3 },
  bags: { accessories: 0.2 },
};
function categoryScore(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  return RELATED[a]?.[b] || 0;
}

function hexToRgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function colorSim(a, b) {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  const rm = (r1 + r2) / 2; // distance « redmean », approximation perceptuelle
  const d = Math.sqrt((2 + rm / 256) * (r1 - r2) ** 2 + 4 * (g1 - g2) ** 2 + (2 + (255 - rm) / 256) * (b1 - b2) ** 2);
  return Math.max(0, 1 - d / 260);
}
function colorScore(itemColors, listingColors) {
  const a = (itemColors || []).filter((c) => COLORS[c]);
  const b = (listingColors || []).filter((c) => COLORS[c]);
  if (!a.length || !b.length) return null; // inconnu : n'influence pas le score
  return a.reduce((s, c) => s + Math.max(...b.map((p) => colorSim(COLORS[c].hex, COLORS[p].hex))), 0) / a.length;
}

export function itemTokens(item) {
  return tokens(item.label, item.model, item.fit, item.materials, item.details, item.patterns, item.logos_text, item.keywords);
}

/**
 * @param {Array} listings  annonces actives { id, brand_slug, brandName, title, category, categoryName, colors[], description, size, price }
 * @param {object} item     pièce analysée (server/vision.mjs) ou critères WANTED
 * @param {object} opts     { mode: 'exact' | 'similar', visual?: Map<id, cosinus 0..1>, limit }
 */
export function rank(listings, item, { mode = 'similar', visual = null, limit = 48 } = {}) {
  const itTok = itemTokens(item);
  const modelTok = tokens(item.model);
  const brand = item.brand && item.brand !== 'unknown' ? item.brand : '';
  const brandConf = brand ? Math.min(1, Math.max(0.3, Number(item.brand_confidence) || 0.5)) : 0;
  const W = mode === 'exact'
    ? { cat: 0.25, brand: 0.35, color: 0.15, kw: 0.25 }
    : { cat: 0.35, brand: 0.15, color: 0.25, kw: 0.25 };
  const hasVisual = visual && visual.size > 0;

  const out = [];
  for (const l of listings) {
    const lt = tokens(l.title, l.description, l.brandName, l.categoryName);
    const s = {
      cat: categoryScore(item.category, l.category),
      brand: brand && l.brand_slug === brand ? brandConf : 0,
      color: colorScore(item.colors, l.colors),
      kw: 0,
      model: 0,
    };
    if (itTok.size) {
      let hit = 0;
      for (const t of itTok) if (lt.has(t)) hit += 1;
      s.kw = Math.min(1, hit / Math.min(itTok.size, 6));
    }
    if (modelTok.size) {
      let hit = 0;
      for (const t of modelTok) if (lt.has(t)) hit += 1;
      s.model = hit / modelTok.size;
    }
    // Couleur non renseignée par le vendeur : on répartit son poids sur les autres critères.
    const wColor = s.color == null ? 0 : W.color;
    const norm = W.cat + W.brand + W.kw + wColor;
    let score = (W.cat * s.cat + W.brand * s.brand + W.kw * Math.max(s.kw, s.model) + wColor * (s.color || 0)) / norm;
    if (hasVisual) score = 0.6 * score + 0.4 * (visual.get(l.id) || 0);

    if (mode === 'exact') {
      // Pièce exacte : même catégorie, même marque, modèle ou détails concordants, couleur compatible.
      const ok = s.cat === 1 && s.brand > 0 && (s.model >= 0.6 || s.kw >= 0.5) && (s.color == null || s.color >= 0.55);
      if (!ok) continue;
      score = Math.max(score, 0.6 + 0.4 * Math.max(s.model, s.kw));
    } else if (score < 0.4) {
      continue;
    }
    out.push({ l, score });
  }
  out.sort((a, b) => b.score - a.score);
  return out.slice(0, limit).map(({ l, score }) => ({ id: l.id, similarity: Math.min(99, Math.round(score * 100)) }));
}
